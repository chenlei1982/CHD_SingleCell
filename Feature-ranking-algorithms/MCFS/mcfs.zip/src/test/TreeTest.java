package test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.FArray;
import dmLab.array.loader.File2Array;
import dmLab.classifier.WekaClassifier;
import dmLab.classifier.j48.J48Classifier;
import dmLab.classifier.m5.M5Classifier;
import dmLab.classifier.m5.M5Params;
import dmLab.mcfs.tree.Tree;
import dmLab.mcfs.tree.TreeNode;
import dmLab.mcfs.tree.parser.J48Parser;
import dmLab.mcfs.tree.parser.M5Parser;
import dmLab.mcfs.tree.parser.TreeParser;
import dmLab.utils.StringUtils;

public class TreeTest {
	public static String resourcesPath;
	public static FArray weatherArray = new FArray();
	public static FArray irisArray = new FArray();
	public static FArray soybeanArray = new FArray();
	public static FArray communitiesArray = new FArray();
	
	//***************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");		
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		File2Array file2Container=new File2Array();		
		assertTrue("weather",file2Container.load(weatherArray, resourcesPath+"//weather.adx"));
		assertTrue("iris",file2Container.load(irisArray, resourcesPath+"//iris.adx"));
		assertTrue("soybean",file2Container.load(soybeanArray, resourcesPath+"//soybean.adx"));
		assertTrue("CommunitiesDataSmall",file2Container.load(communitiesArray, resourcesPath+"//CommunitiesDataSmall.adx"));		
		System.out.println("#### END before ####");	
	}
	//***************************	
	@Test
	public void testJ48() {
		System.out.println("#### testJ48 ####");
		weatherArray.findDomains();
        weatherArray.setDecAttrIdx(4);
		System.out.println(weatherArray.toString());
		WekaClassifier j48 = new J48Classifier();		
		j48.train(weatherArray);
		((J48Classifier)j48).setPrintNodeIndicators(true);		
        String j48String = j48.toString();
        System.out.println(j48String);        
        TreeParser treeParser = new J48Parser(j48String);                
        Tree tree = new Tree(treeParser);
        System.out.println(tree.toString());
        String t = 
        		"outlook=sunny	#0#0.24674982#0.15642756#14.0#" +"\n"
        		+ "|   humidity<=75	:yes	#1#0.7709506#0.7940163#5.0#"+"\n"
        		+ "|   humidity>75	:no	#1#0.7709506#0.7940163#5.0#"+"\n"
        		+ "outlook=overcast	:yes	#0#0.24674982#0.15642756#14.0#" +"\n"
        		+ "outlook=rainy	#0#0.24674982#0.15642756#14.0#"+"\n"
        		+ "|   windy=false	:yes	#5#0.9709506#1.0#5.0#"+"\n"
        		+ "|   windy=true	:no	#5#0.9709506#1.0#5.0#";
        		
        System.out.println(t);   
        assertEquals(t, tree.toString().trim());        
	}	
	//***************************	
	@Test
	public void testM5() {
		System.out.println("#### testM5 ####");
		weatherArray.findDomains();
		weatherArray.setDecAttrIdx(1);
		System.out.println(weatherArray.toString());
		WekaClassifier m5 = new M5Classifier();
		((M5Params)m5.getParams()).unpruned = true;
		((M5Params)m5.getParams()).unsmoothed = true;
		m5.train(weatherArray);
		m5.test(weatherArray);

		((M5Classifier)m5).setPrintNodeIndicators(true);
		String m5String = m5.toString();
        System.out.println(m5String);		

		TreeParser treeParser = new M5Parser(m5String);                
        Tree tree = new Tree(treeParser);
        System.out.println(tree.toString());

        tree.initNodesIterating();
        TreeNode n = tree.getNextNode();
        n = tree.getNextNode();
        n = tree.getNextNode();
        System.out.println(n.printNode());        	
        String refNode = "outlook=sunny	#2#0.64116424#0.64116424#4.0#";
        assertEquals(refNode, n.printNode().trim());

		
        communitiesArray.findDomains();
        communitiesArray.setDecAttrIdx(communitiesArray.colsNumber());
		m5.train(communitiesArray);
		((M5Classifier)m5).setPrintNodeIndicators(true);

        m5String = m5.toString();
        System.out.println(m5String);
		m5.test(communitiesArray);
                
		treeParser = new M5Parser(m5String);                
        tree = new Tree(treeParser);
        //System.out.println(tree.toString());
        
        tree.initNodesIterating();
        n = tree.getNextNode();
        String actualNode = n.printNode().trim();

        System.out.println(n.printNode());        	
        	
        refNode = "communityname=DalyCitycity,Evansvillecity,Ogdencity,Kingsportcity,SanLuisObispocity,SanDimascity,Daltoncity,TheVillagecity,SilverCitytown,Napacity,ElCampocity,Reddingcity,Cumberlandtown,Torrancecity,LaMiradacity,MichiganCitycity,Marinacity,Killeencity,Mansfieldcity,Genevacity,Amarillocity,Allentowncity,MineralWellscity,Hyattsvillecity,LakeStationcity,Fillmorecity,Antiochcity,Yonkerscity,Taylorcity,WestMemphiscity,FortDodgecity,NiagaraFallscity,Peekskillcity,Sangercity,Lynchburgcity,Delanocity,Visaliacity,Eriecity,Zanesvillecity,Englewoodcity,Hollywoodcity,Modestocity,PhenixCitycity,SanGabrielcity,Nogalescity,WiltonManorscity,Northportcity,Hurstcity,Montgomerycity,Pittsburgcity,Vancouvercity,Lancastercity,Greensborocity,Westfieldcity,Monroecity,Banningcity,Maldencity,UnionCitycity,Lawtoncity,Artesiacity,RohnertParkcity,Tucsoncity,Savannahcity,Enterprisecity,Decaturcity,Lexingtoncity,Aberdeentown,Bogalusacity,Passaiccity,SouthBendcity,Newarkcity,Eurekacity,BeverlyHillscity,Salisburycity,Palestinecity,Clearwatercity,Georgetowncity,Albanycity,Beckleycity,Lodicity,PerthAmboycity,Marysvillecity,Cantoncity,LongBranchcity,LaPortecity,Lowellcity,ElMontecity,Selmacity,Huntsvillecity,BoyntonBeachcity,CasaGrandecity,Seattlecity,Greenvillecity,WinterHavencity,Gastoniacity,Watsonvillecity,Hendersoncity,SiouxCitycity,Lakelandcity,Newberrytown,KeyWestcity,Bartowcity,OaklandParkcity,LongBeachcity,Richmondcity,Tukwilacity,Riversidecity,PortArthurcity,SantaMonicacity,Jacksonvillecity,Greenfieldtown,Pueblocity,Bellflowercity,Lynncity,Pariscity,Charlottecity,Auroracity,Fairfieldcity,JerseyCitycity,Gardenacity,Fayettevillecity,Inglewoodcity,LakeCitycity,NewHaventown,NorthCharlestoncity,Spartanburgcity,AtlanticCitycity,Birminghamcity,Vernoncity,PlantCitycity,BatonRougecity	#0#0.15037723#0.15037723#367.0#";
        String[] refNodeVals = StringUtils.tokenize(refNode.substring(refNode.indexOf('=')+1,refNode.indexOf('#')).trim(), new char[] {','}, new char[] {'"'});
        Arrays.sort(refNodeVals);
        
        String[] actualNodeVals = StringUtils.tokenize(actualNode.substring(actualNode.indexOf('=')+1,actualNode.indexOf('#')).trim(), new char[] {','}, new char[] {'"'});
        Arrays.sort(actualNodeVals);

        assertEquals(refNode.substring(0,refNode.indexOf('=')), 
        		actualNode.substring(0,actualNode.indexOf('=')));        
        assertEquals(refNode.substring(refNode.indexOf('#'),refNode.length()), 
        			actualNode.substring(actualNode.indexOf('#'),actualNode.length()));

        assertEquals(refNodeVals.length, actualNodeVals.length);
        for(int i=0; i<actualNodeVals.length; i++)
        	assertEquals(refNodeVals[i], actualNodeVals[i]);        
	}
	//***************************	

}
