package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.Array;
import dmLab.array.FArray;
import dmLab.array.functions.SelectFunctions;
import dmLab.array.loader.File2Array;
import dmLab.classifier.adx.ADXClassifier;
import dmLab.utils.FileUtils;
import dmLab.utils.cmatrix.QualityMeasure;
import dmLab.utils.cmatrix.ConfusionMatrix;

public class ADXTest {
	public static String resourcesPath;
	public static FArray weatherArray = new FArray();
	public static FArray irisArray = new FArray();
	public static FArray soybeanArray = new FArray();
	
	//***************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");		
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		File2Array file2Container=new File2Array();		
		assertTrue("weather",file2Container.load(weatherArray, resourcesPath+"//weather.adx"));
		assertTrue("iris",file2Container.load(irisArray, resourcesPath+"//iris.adx"));
		assertTrue("soybean",file2Container.load(soybeanArray, resourcesPath+"//soybean.adx"));
		System.out.println("#### END before ####");	
	}
	//***************************	
	@Test
	public void testTrainingIris() {
		System.out.println("#### testTrainingIRIS ####");

		FArray inputArray = irisArray;
		int[] splitMask = new int[inputArray.rowsNumber()];
		for(int i=0; i<splitMask.length; i++){
			if(i%2==0)
				splitMask[i]=1;
		}
		Array[] trainTestArrays = SelectFunctions.split(inputArray, splitMask);		
		FArray trainArray = (FArray)trainTestArrays[0];
		FArray testArray = (FArray)trainTestArrays[1];
		
		//train on numeric data
		ADXClassifier adx = new ADXClassifier();
		adx.train(trainArray);
		String refIrisRules = FileUtils.loadString(resourcesPath+"adx.iris.rules.txt");
		String adxIrisRules = adx.toString();
		System.out.println(adxIrisRules.trim());
		assertEquals(refIrisRules.trim(), adxIrisRules.trim());

		adx.test(testArray);
		ConfusionMatrix cm = adx.getPredResult().getConfusionMatrix();
		System.out.print(cm.toString());
		float acc = cm.calcMeasure(QualityMeasure.ACC);
		float wacc = cm.calcMeasure(QualityMeasure.WACC);
		assertEquals(new Float(0.6f), new Float(acc));
		assertEquals(new Float(0.6f), new Float(wacc));		
	}
	//***************************
	@Test
	public void testTrainingWeather() {
		System.out.println("#### testTrainingWeather ####");

		FArray inputArray = weatherArray;
		int[] splitMask = new int[inputArray.rowsNumber()];
		for(int i=0; i<splitMask.length; i++){
			if(i%2==0)
				splitMask[i]=1;
		}
		System.out.println(inputArray.toString());
		System.out.println(inputArray.getDecAttrIdx());
		System.out.println(Arrays.toString(inputArray.getDecValuesStr()));
		
		Array[] trainTestArrays = SelectFunctions.split(inputArray, splitMask);		
		FArray trainArray = (FArray)trainTestArrays[0];
		FArray testArray = (FArray)trainTestArrays[1];
		
		
		//train on numeric data
		ADXClassifier adx = new ADXClassifier();
		adx.params.verbose = true;
		adx.train(trainArray);
		
		System.out.println("###################");
				
		String refWeatherRules = FileUtils.loadString(resourcesPath+"adx.weather.rules.txt");
		String adxWeatherRules = adx.toString();
		System.out.println(adxWeatherRules.trim());
		assertEquals(refWeatherRules.trim(), adxWeatherRules.trim());

		adx.saveDefinition("./results/", "weatherTest");
		adx = new ADXClassifier();
		adx.loadDefinition("./results/", "weatherTest");
		
		adx.test(testArray);
		ConfusionMatrix cm = adx.getPredResult().getConfusionMatrix();
		System.out.print(cm.toString());
		float acc = cm.calcMeasure(QualityMeasure.ACC);
		float wacc = cm.calcMeasure(QualityMeasure.WACC);
		assertEquals(new Float(0.5714286f), new Float(acc));
		assertEquals(new Float(0.625f), new Float(wacc));		
	}
	//***************************
}
