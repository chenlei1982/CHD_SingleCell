package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.FArray;
import dmLab.array.loader.File2Array;
import dmLab.mcfs.MCFSParams;
import dmLab.mcfs.attributesRI.AttributesRI;
import dmLab.mcfs.attributesRI.Ranking;
import dmLab.mcfs.cutoffMethods.Cutoff;
import dmLab.mcfs.mcfsEngine.MCFSExperiment;
import dmLab.mcfs.mcfsEngine.framework.GlobalStats;
import dmLab.utils.cmatrix.QualityMeasure;
import dmLab.utils.dataframe.DataFrame;

public class MCFSTest {

	public static String resourcesPath;
	public static FArray aliArray = new FArray();
	public static FArray artArray = new FArray();
	
	//***************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");	
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		File2Array file2Container=new File2Array();
		assertTrue("artificialData",file2Container.load(artArray, resourcesPath+"//artificialData.adx"));
		System.out.println("#### END before ####");
	}
	//***************************	
	@Test
	public void testCutoff(){
		System.out.println("#### testCutoff ####");
		AttributesRI attributesImportance = new AttributesRI();
		String inFileName = resourcesPath+"AlizadehData__importances.csv";
		attributesImportance.load(inFileName);
		Cutoff cutoff = new Cutoff(new MCFSParams());
		cutoff.calcCutoff(attributesImportance);
		System.out.println(cutoff.toString());

		DataFrame c = cutoff.getCutoffTable();

		int rowIdx = c.getFirstRowIdx(c.getColIdx("method"), "kmeans");
		int colIdx = c.getColIdx("size");
		assertEquals(new Double(46),(Double)c.get(rowIdx, colIdx));

		rowIdx = c.getFirstRowIdx(c.getColIdx("method"), "mean");
		colIdx = c.getColIdx("minRI");
		assertEquals(new Double(0.13161906599998474),(Double)c.get(rowIdx, colIdx));				
	}
	//***************************
	@Test
	public void testRanking(){
		System.out.println("#### testRanking ####");
		String inFileName = resourcesPath+"AlizadehData__importances.csv";		

		AttributesRI imp1 = new AttributesRI();
		imp1.load(inFileName);

		AttributesRI imp2 = new AttributesRI();
		imp2.load(inFileName);

		int size = 50;        
		Ranking rank1=imp1.getTopRankingSize(imp1.mainMeasureIdx,size); 
		Ranking rank2=imp2.getTopRankingSize(imp2.mainMeasureIdx,size);
		rank1.normalize=rank2.normalize=true;
		System.out.println(rank1.toString());		
		assertEquals(size,rank1.commonNumber(rank2));
		assertEquals("GENE1622X",rank1.getAttributesNames()[0]);
		assertEquals("RI_norm",rank1.getMeasureName());
		assertEquals(new Double(0),new Double(rank1.compare(rank2)));
	}
	//***************************
	@Test
	public void testArtificial(){
		System.out.println("#### testArtificial ####");		
		MCFSParams mcfsParams = new MCFSParams();
		mcfsParams.threadsNumber = 4;
		mcfsParams.projectionsValue = 100;
		mcfsParams.projectionSizeValue = 4;
		mcfsParams.cutoffPermutations = 3;
		mcfsParams.finalCV = false;
		mcfsParams.finalRuleset = true;				
		mcfsParams.progressShow = false;
		mcfsParams.inputFilesPATH = ".//src//test//resources//"; 
		mcfsParams.inputFileName = "artificialData.adx";
		mcfsParams.seed = 0;
		System.out.println(mcfsParams.toString());

		MCFSExperiment mcfs = new MCFSExperiment(mcfsParams);
		mcfs.run();
		
		GlobalStats gstats = mcfs.getGlobalStats();
		AttributesRI attrRI = gstats.getAttrImportances()[0];		
		Ranking topRanking = attrRI.getTopRankingSize(attrRI.mainMeasureIdx, 6);
		String[] topAttr = topRanking.getAttributesNames();
		System.out.println(Arrays.toString(topAttr));
		assertEquals('A', topAttr[0].charAt(0));
		assertEquals('A', topAttr[1].charAt(0));
		assertEquals('B', topAttr[2].charAt(0));
		assertEquals('B', topAttr[3].charAt(0));
	}
	//***************************
	@Test
	public void testArtificialNA(){
		System.out.println("#### testArtificialNA ####");		
		MCFSParams mcfsParams = new MCFSParams();
		mcfsParams.threadsNumber = 4;
		mcfsParams.projectionsValue = 100;
		mcfsParams.projectionSizeValue = 4;
		mcfsParams.cutoffPermutations = 3;
		mcfsParams.finalCV = false;
		mcfsParams.finalRuleset = true;				
		mcfsParams.progressShow = false;
		mcfsParams.inputFilesPATH = ".//src//test//resources//"; 
		mcfsParams.inputFileName = "artificialDataNA.adx";
		mcfsParams.seed = 0;
		System.out.println(mcfsParams.toString());

		MCFSExperiment mcfs = new MCFSExperiment(mcfsParams);
		mcfs.run();
		
		GlobalStats gstats = mcfs.getGlobalStats();
		AttributesRI attrRI = gstats.getAttrImportances()[0];		
		Ranking topRanking = attrRI.getTopRankingSize(attrRI.mainMeasureIdx, 6);
		String[] topAttr = topRanking.getAttributesNames();
		System.out.println(Arrays.toString(topAttr));
		assertEquals('A', topAttr[0].charAt(0));
		assertEquals('A', topAttr[1].charAt(0));
		assertEquals('B', topAttr[2].charAt(0));
		assertEquals('B', topAttr[3].charAt(0));
	}
	//***************************
	@Test
	public void testArtificialDataWeights() {
		System.out.println("#### testArtificialDataWeights ####");		
		MCFSParams mcfsParams = new MCFSParams();
		String paramsFileName = "AlizadehData.run";
		mcfsParams.load(resourcesPath,paramsFileName);
		mcfsParams.threadsNumber = 6;
		mcfsParams.projections = 100;
		mcfsParams.projectionSize = 3;
		mcfsParams.buildID = true;
		mcfsParams.cutoffPermutations = 0;		
		mcfsParams.progressShow=false;
		mcfsParams.seed = 0;
		mcfsParams.finalCV = false;		
		mcfsParams.inputFilesPATH = resourcesPath;
		mcfsParams.inputFileName = "artificialDataWeights.adx"; 

		System.out.println(mcfsParams.toString());						
		MCFSExperiment mcfs = new MCFSExperiment(mcfsParams);		
		mcfs.run();
		
		GlobalStats gstats = mcfs.getGlobalStats();
		double wacc = gstats.getConfusionMatrix().calcMeasure(QualityMeasure.WACC);
		double acc = gstats.getConfusionMatrix().calcMeasure(QualityMeasure.ACC); 
		System.out.println("wacc: "+wacc);
		System.out.println("acc: "+acc);

		String colNames = Arrays.toString(mcfs.getArrays().sourceArray.getColNames(true));
		String refColNames = "[X1, X2, X3, x_mcfs_contrast_attr_1, X5, X6, x_mcfs_contrast_attr_1.1, X1.1, x_mcfs_contrast_attr_2, X3.1, A1, A2, B1, B2, C1, C2, class]";
		System.out.println(colNames);
		assertEquals(refColNames,colNames);		

		//System.out.println(gstats.getCutoff().getCutoffTable());
		AttributesRI attrRI = gstats.getAttrImportances()[0];		
		System.out.println(attrRI.toString());
		float[] projections = attrRI.getImportanceValues(0);

		System.out.println(Arrays.toString(attrRI.getImportanceValues(0)));
		System.out.println(projections[0]/projections[7]);				
		assertTrue(projections[0]/projections[7]>8 && projections[0]/projections[7]<12);
	}
	//***************************
	@Test
	public void testArtificial_M5(){
		System.out.println("#### testArtificial_M5 ####");		
		MCFSParams mcfsParams = new MCFSParams();
		mcfsParams.threadsNumber = 4;
		mcfsParams.projectionsValue = 100;
		mcfsParams.projectionSizeValue = 4;
		mcfsParams.cutoffPermutations = 3;
		mcfsParams.finalCV = false;
		mcfsParams.finalRuleset = true;				
		mcfsParams.progressShow = false;
		mcfsParams.inputFilesPATH = ".//src//test//resources//"; 
		mcfsParams.inputFileName = "adata.m5.adx";
		mcfsParams.seed = 0;
		System.out.println(mcfsParams.toString());

		MCFSExperiment mcfs = new MCFSExperiment(mcfsParams);
		mcfs.run();
		
		GlobalStats gstats = mcfs.getGlobalStats();
		AttributesRI attrRI = gstats.getAttrImportances()[0];		
		Ranking topRanking = attrRI.getTopRankingSize(attrRI.mainMeasureIdx, 6);
		String[] topAttr = topRanking.getAttributesNames();
		System.out.println(Arrays.toString(topAttr));
		
		assertEquals('A', topAttr[0].charAt(0));
		assertEquals('A', topAttr[1].charAt(0));
		assertEquals('B', topAttr[2].charAt(0));
		assertEquals('B', topAttr[3].charAt(0));
	}
	//***************************
	@Test
	public void testNoImportantFeatures(){
		System.out.println("#### testNoImportantFeatures ####");		
		MCFSParams mcfsParams = new MCFSParams();
		mcfsParams.mode = 2;
		mcfsParams.threadsNumber = 4;
		mcfsParams.cutoffMethod = "permutations";
		mcfsParams.cutoffPermutations = 5;
		mcfsParams.finalCV = true;
		mcfsParams.finalRuleset = true;
		mcfsParams.progressShow = false;
		mcfsParams.inputFilesPATH = ".//src//test//resources//"; 
		mcfsParams.inputFileName = "subtype_DAXX_status.adx";
		mcfsParams.seed = 0;
		System.out.println(mcfsParams.toString());

		MCFSExperiment mcfs = new MCFSExperiment(mcfsParams);
		mcfs.run();
		
		GlobalStats gstats = mcfs.getGlobalStats();
		AttributesRI attrRI = gstats.getAttrImportances()[0];		
		Ranking topRanking = attrRI.getTopRankingSize(attrRI.mainMeasureIdx, 6);
		String[] topAttr = topRanking.getAttributesNames();
		System.out.println(Arrays.toString(topAttr));
		
		assertEquals(0, mcfs.topRankingSize);
	}
	//***************************
	


}
