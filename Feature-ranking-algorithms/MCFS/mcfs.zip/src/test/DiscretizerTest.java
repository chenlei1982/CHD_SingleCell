package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.FArray;
import dmLab.array.functions.DiscFunctions;
import dmLab.array.loader.File2Array;
import dmLab.array.meta.DiscRanges;
import dmLab.discretizer.Discretizer;
import dmLab.discretizer.DiscretizerParams;

public class DiscretizerTest {

	public static String resourcesPath;
	public static FArray weatherArray = new FArray();

	//***************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");		
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		File2Array file2Container=new File2Array();		
		assertTrue("weather",file2Container.load(weatherArray, resourcesPath+"//weather.adx"));
		System.out.println("#### END before ####");	
	}
	//***************************
	@Test
	public void equalRangesTest() 
	{
		System.out.println("#### equalRangesTest ####");		
		float attributeArray[]= new float[]{85,80,83,100,68,65,64,72,69,75,Float.NaN,75,72,81,71};        
		float decisionArray[]=new float[]{3,3,1,1,1,3,1,3,1,1,3,1,1,1,3};
		DiscRanges d=new DiscRanges();
		DiscretizerParams discParams=new DiscretizerParams();
		discParams.discAlgorithm=Discretizer.EQUAL_RANGES;

		discParams.discIntervals = 2;
		System.out.println(discParams.toString());
		d.find(attributeArray, decisionArray, discParams);
		System.out.println(" --- disc ranges --- "+Arrays.toString(d.getRanges()));        
		float[] ref = {82.0f, 100f};
		assertTrue(Arrays.equals(ref, d.getRanges()));

		discParams.discIntervals = 3;
		System.out.println(discParams.toString());
		d.find(attributeArray, decisionArray, discParams);
		System.out.println(" --- disc ranges --- "+Arrays.toString(d.getRanges()));        
		float[] ref2 = {76.0f, 88.0f, 100f};
		assertTrue(Arrays.equals(ref2, d.getRanges()));
		
		attributeArray= new float[]{Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN};        
		decisionArray=new float[]{1,1,1,2,2,2,2};
		d.find(attributeArray, decisionArray, discParams);
		System.out.println(" --- disc ranges --- "+Arrays.toString(d.getRanges()));
		assertTrue(d.getRanges()==null);				
	}
	//***************************
	@Test
	public void equalFreqTest() 
	{
		System.out.println("#### equalFreqTest ####");		
		float[] attributeArray = new float[]{85,80,83,100,68,65,64,72,69,75,Float.NaN,75,72,81,71,Float.NaN,Float.NaN,Float.NaN,Float.NaN};        
		float[] decisionArray = new float[]{3,3,1,1,1,3,1,3,1,1,3,1,1,1,3};

		float[] a = attributeArray.clone();
		Arrays.sort(a);
		System.out.println(Arrays.toString(a));     

		DiscRanges d=new DiscRanges();
		DiscretizerParams discParams=new DiscretizerParams();
		discParams.discAlgorithm=Discretizer.EQUAL_FREQUENCY;
		
		discParams.discIntervals = 2;        
		System.out.println(discParams.toString());		
		d.find(attributeArray, decisionArray, discParams);
		System.out.println(" --- disc ranges --- "+Arrays.toString(d.getRanges()));        
		float[] ref = {73.5f, 100f};
		assertTrue(Arrays.equals(ref, d.getRanges()));

		discParams.discIntervals = 3;
		System.out.println(discParams.toString());
		d.find(attributeArray, decisionArray, discParams);
		System.out.println(" --- disc ranges --- "+Arrays.toString(d.getRanges()));        
		float[] ref2 = {71.5f, 80.5f, 100f};
		assertTrue(Arrays.equals(ref2, d.getRanges()));
		
		attributeArray= new float[]{Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN};        
		decisionArray=new float[]{1,1,1,2,2,2,2};
		d.find(attributeArray, decisionArray, discParams);
		System.out.println(" --- disc ranges --- "+Arrays.toString(d.getRanges()));        
		assertTrue(d.getRanges()==null);
	}
	//***************************
	@Test
	public void fayyadIraniTest()
	{		
		System.out.println("#### FayyadIraniTest ####");
		float attributeArray[]= new float[]{60,Float.NaN,64,65,70,72 ,73 ,78,89, 90,93,99,100,101,103};
		float decisionArray[]=new float[]{1,1,1,1,1,1, 3, 1,1, 3,3,3,3,3,3};		
		/*
	    attributeArray= new float[]{-3,-2,-1,0,0,0,0,0,0,0,0,0,0,1,1,1,2,3,4,5,6,6,6,6,6,7,7,8};
	    decisionArray = new float[]{2,2,2,1,1,1,2,2,2,2,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2};

        attributeArray= new float[]{-0.32f, -0.51f, 0.2f, -0.36f, -0.13f, 0.14f, -0.18f, 0.38f, -0.06f, -0.27f, 0.44f, 0.05f, 0.0f, -0.13f, 0.05f, -0.43f, 0.17f, 0.15f, 0.81f, -0.16f, 0.42f, 0.13f, -0.72f, 0.06f, 0.22f, 0.07f, 0.02f, 0.28f, -0.36f, 0.37f, 0.06f, -0.28f, -1.18f, -0.86f, -0.78f, -0.19f, 0.04f, -0.84f, 0.77f, -0.03f, 0.09f};
        decisionArray=new float[]{2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 4.0f, 4.0f, 4.0f, 4.0f, 4.0f};
		*/
		DiscRanges d=new DiscRanges();
		DiscretizerParams discParams=new DiscretizerParams();
		discParams.verbose = true;
        discParams.discAlgorithm=Discretizer.FAYYAD_IRANI;

		discParams.discIntervals = 2;
        System.out.println(discParams.toString());
        
        d.find(attributeArray, decisionArray, discParams);
        System.out.println(" --- disc ranges --- "+Arrays.toString(d.getRanges()));
        
		float[] ref = {89.5f, 103f};
		assertTrue(Arrays.equals(ref, d.getRanges()));
		
		attributeArray= new float[]{Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN};        
		decisionArray=new float[]{1,1,1,2,2,2,2};
		d.find(attributeArray, decisionArray, discParams);
		System.out.println(" --- disc ranges --- "+Arrays.toString(d.getRanges()));        
		assertTrue(d.getRanges()==null);

		/* /
	        //this is an example how to use the same discretization function implemented in WEKA
	        //Class DiscretizeFI is taken from Weka slightly modified by MDR to see
	        //what is going inside it

	        Instances instances=Array2Instances.convert(sourceArray);
	        DiscretizeFI wekaDiscretize = new DiscretizeFI();

	        //wekaDiscretize.setUseBetterEncoding(true);        

	        try {
	            wekaDiscretize.setInputFormat(instances);
	            instances = Filter.useFilter(instances, wekaDiscretize);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        System.out.println(Arrays.toString(wekaDiscretize.getCutPoints(attrIndex)));
	      // */
	}
	//*******************************************************
	@Test
	public void chiMergeTest() 
	{
		System.out.println("#### chiMergeTest ####");
		float attributeArray[]= new float[]{60,Float.NaN,64,65,70,72 ,73 ,78,89, 90,93,99,100,101,103};
		float decisionArray[]=new float[]{1,1,1,1,1,1, 3, 1,1, 3,3,3,3,3,3};
		/*
	    attributeArray= new float[]{-3,-2,-1,0,0,0,0,0,0,0,0,0,0,1,1,1,2,3,4,5,6,6,6,6,6,7,7,8};
	    decisionArray = new float[]{2,2,2,1,1,1,2,2,2,2,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2};

        attributeArray= new float[]{-0.32f, -0.51f, 0.2f, -0.36f, -0.13f, 0.14f, -0.18f, 0.38f, -0.06f, -0.27f, 0.44f, 0.05f, 0.0f, -0.13f, 0.05f, -0.43f, 0.17f, 0.15f, 0.81f, -0.16f, 0.42f, 0.13f, -0.72f, 0.06f, 0.22f, 0.07f, 0.02f, 0.28f, -0.36f, 0.37f, 0.06f, -0.28f, -1.18f, -0.86f, -0.78f, -0.19f, 0.04f, -0.84f, 0.77f, -0.03f, 0.09f};
        decisionArray=new float[]{2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 3.0f, 4.0f, 4.0f, 4.0f, 4.0f, 4.0f};
		 */
		
		DiscRanges d=new DiscRanges();
		DiscretizerParams discParams=new DiscretizerParams();
        discParams.discAlgorithm=Discretizer.CHI2;
		discParams.discIntervals = 2;
        System.out.println(discParams.toString());
        
        d.find(attributeArray, decisionArray, discParams);
        System.out.println(" --- disc ranges --- "+Arrays.toString(d.getRanges()));
        
		float[] ref = {72.5f,75.5f,89.5f, 103f};
		assertTrue(Arrays.equals(ref, d.getRanges()));
		
		attributeArray= new float[]{Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN,Float.NaN};        
		decisionArray=new float[]{1,1,1,2,2,2,2};
		d.find(attributeArray, decisionArray, discParams);
		System.out.println(" --- disc ranges --- "+Arrays.toString(d.getRanges()));
		assertTrue(d.getRanges()==null);
	}
	//***************************
	@Test
	public void applyDiscretizerTest() 
	{
		System.out.println("#### applyDiscretizerTest ####");
		FArray inputArray = weatherArray;
		inputArray.writeValue(1, 1, Float.NaN);
		DiscretizerParams discParams=new DiscretizerParams();
		discParams.discIntervals = 3;
        discParams.discAlgorithm = Discretizer.EQUAL_RANGES;
        discParams.verbose = true;
        System.out.println(discParams.toString());
        
		DiscFunctions.findRanges(inputArray, discParams);
		inputArray.writeValue(1, 5, 120);
		
		System.out.println(inputArray.toString());
		DiscFunctions.applyRanges(inputArray);		
		System.out.println(inputArray.toString());
		
		System.out.println(Arrays.toString(inputArray.getColumn(1)));
		float[] refCol = {85.0f, Float.NaN, 85.0f, 71.0f, 71.0f, 85.0f, 71.0f, 78.0f, 71.0f, 78.0f, 78.0f, 78.0f, 85.0f, 71.0f};		
		assertTrue(Arrays.equals(refCol, inputArray.getColumn(1)));

		System.out.println(inputArray.discRanges[1].toString());
		assertTrue(inputArray.discRanges[1].toString().equalsIgnoreCase("71.0, 78.0, 85.0"));
				
		System.out.println(inputArray.discRanges[1].getRangeStr(66f));
		assertTrue(inputArray.discRanges[1].getRangeStr(66f).equalsIgnoreCase("(-Infinity;71.0]"));
		
		System.out.println(inputArray.discRanges[1].getRangeStr(77f));
		assertTrue(inputArray.discRanges[1].getRangeStr(77f).equalsIgnoreCase("(71.0;78.0]"));
		
		assertEquals(new Double(85f), new Double(inputArray.discRanges[1].getDiscreteValue(99f)));
		
		System.out.println(inputArray.discRanges[1].getRangeStr(99f));
		assertTrue(inputArray.discRanges[1].getRangeStr(99f).equalsIgnoreCase("(78.0;Infinity]"));		
	}	
	//***************************
	@Test
	public void saveLoadDiscRangesTest()	
	{
		System.out.println("#### saveLoadDiscRangesTest ####");
		FArray inputArray = weatherArray;
		inputArray.writeValue(1, 1, Float.NaN);
		DiscretizerParams discParams=new DiscretizerParams();
		discParams.discIntervals = 3;
        discParams.discAlgorithm = Discretizer.EQUAL_RANGES;
        discParams.verbose = true;
        
		DiscFunctions.findRanges(inputArray, discParams);
		String rangesStr = DiscFunctions.toStringRanges(inputArray);
				
		String refString = "Attribute: 0 # outlook\n"+
		"Discretized: false\n"+
		"Attribute: 1 # temperature\n"+
		"Discretized: true\n"+
		"Ranges: 3\n"+
		"71.0, 78.0, 85.0\n"+
		"Attribute: 2 # humidity\n"+
		"Discretized: true\n"+
		"Ranges: 3\n"+
		"75.333336, 85.666664, 96.0\n"+
		"Attribute: 3 # windy\n"+
		"Discretized: false\n"+
		"Attribute: 4 # play\n"+
		"Discretized: false\n";
		
		System.out.println(rangesStr);
		assertEquals(refString, rangesStr);		
	}
	//***************************
}
