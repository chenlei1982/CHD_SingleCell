package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.FArray;
import dmLab.mcfs.MCFSParams;
import dmLab.mcfs.attributesRI.AttributesRI;
import dmLab.mcfs.attributesRI.Ranking;
import dmLab.mcfs.mcfsEngine.MCFSExperiment;
import dmLab.mcfs.mcfsEngine.framework.GlobalStats;
import dmLab.utils.MathUtils;
import dmLab.utils.cmatrix.QualityMeasure;

public class AlizadehTest {

	public static String resourcesPath;
	public static FArray aliArray = new FArray();
	
	//***************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");	
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		System.out.println("#### END before ####");
	}
	//***************************
	@Test
	public void testAlizadeh() {
		
		System.out.println("#### testAlizadeh ####");		
		MCFSParams mcfsParams=new MCFSParams();
		String paramsFileName = "AlizadehData.run";
		mcfsParams.load(resourcesPath,paramsFileName);
		mcfsParams.threadsNumber = 1;
		mcfsParams.projectionSize = 0.05f;
		mcfsParams.projections = 1000;
		mcfsParams.featureFreq = 100;
		mcfsParams.mode = 1;
		mcfsParams.seed = 0;
		System.out.println(mcfsParams.toString());
		
		MCFSExperiment mcfs = new MCFSExperiment(mcfsParams);
		mcfs.run();
		
		GlobalStats gstats = mcfs.getGlobalStats();
		double wacc = gstats.getConfusionMatrix().calcMeasure(QualityMeasure.WACC);
		double acc = gstats.getConfusionMatrix().calcMeasure(QualityMeasure.ACC); 
		System.out.println("wacc: "+wacc);
		System.out.println("acc: "+acc);
		assertEquals(new Double(MathUtils.truncate(0.752,3)), new Double(MathUtils.truncate(wacc,3)));
		assertEquals(new Double(MathUtils.truncate(0.839,3)), new Double(MathUtils.truncate(acc,3)));		

		System.out.println(gstats.getCutoff().getCutoffTable());
		AttributesRI attrRI = gstats.getAttrImportances()[0];		
		Ranking topRanking = attrRI.getTopRankingSize(attrRI.mainMeasureIdx, 12);
		String[] topAttr = topRanking.getAttributesNames();
		String refAttr = "[GENE1622X, GENE1602X, GENE1610X, GENE1553X, GENE1613X, GENE1606X, GENE2426X, GENE639X, GENE2668X, GENE1673X, GENE653X, GENE530X]";
		System.out.println(Arrays.toString(topAttr));
		System.out.println(refAttr);
		
		assertEquals(refAttr.substring(0,70), Arrays.toString(topAttr).substring(0,  70));
	}
	//***************************
	@Test
	public void testAlizadehThreads() {
		
		System.out.println("#### testAlizadehThreads ####");		
		MCFSParams mcfsParams=new MCFSParams();
		String paramsFileName = "AlizadehData.run";
		mcfsParams.load(resourcesPath,paramsFileName);
		mcfsParams.threadsNumber = 4;
		mcfsParams.projectionSize = 0.05f;
		mcfsParams.featureFreq = 100;
		mcfsParams.progressShow = false;
		mcfsParams.seed = 0;
		mcfsParams.mode = 1;
		System.out.println(mcfsParams.toString());
		
		MCFSExperiment mcfs = new MCFSExperiment(mcfsParams);
		mcfs.run();
		
		GlobalStats gstats = mcfs.getGlobalStats();
		double wacc = gstats.getConfusionMatrix().calcMeasure(QualityMeasure.WACC);
		double acc = gstats.getConfusionMatrix().calcMeasure(QualityMeasure.ACC); 
		System.out.println("wacc: "+wacc);
		System.out.println("acc: "+acc);		
		assertEquals(new Double(0.752), new Double(MathUtils.truncate(wacc,3)));
		assertEquals(new Double(0.836), new Double(MathUtils.truncate(acc,3)));		

		System.out.println(gstats.getCutoff().getCutoffTable());
		AttributesRI attrRI = gstats.getAttrImportances()[0];		
		Ranking topRanking = attrRI.getTopRankingSize(attrRI.mainMeasureIdx, 12);
		String[] topAttr = topRanking.getAttributesNames();
		System.out.println(Arrays.toString(topAttr));
		//String[] refAttr = new String[]{"GENE1602X", "GENE1622X", "GENE2668X", "GENE1553X", "GENE2426X"};
		String[] refAttr = new String[]{"GENE1602X", "GENE1622X", "GENE1610X", "GENE1610X", "GENE1553X", "GENE1606X", "GENE1647X"};
		System.out.println(Arrays.toString(refAttr));		
		
		HashSet<String> set = new HashSet<String>();
		Collections.addAll(set, topAttr);
		for(int i=0; i<refAttr.length; i++){
			System.out.println(refAttr[i]);
			assertTrue(set.contains(refAttr[i]));
		}
	}
	//***************************
	@Test
	public void testSimpleAlizadeh() {
		
		System.out.println("#### testAlizadeh ####");		
		MCFSParams mcfsParams=new MCFSParams();
		String paramsFileName = "AlizadehData.run";
		mcfsParams.load(resourcesPath,paramsFileName);
		mcfsParams.threadsNumber = 1;
		mcfsParams.projectionSize = 50;
		mcfsParams.projections = 300;
		mcfsParams.featureFreq = 100;
		mcfsParams.cutoffPermutations = 0;
		mcfsParams.buildID = false;
		mcfsParams.finalRuleset = false;
		mcfsParams.finalCV = false;    
		mcfsParams.progressShow = false;
		mcfsParams.balance = 1;
		mcfsParams.seed = 0;
		mcfsParams.mode = 1;
		System.out.println(mcfsParams.toString());

		MCFSExperiment mcfs = new MCFSExperiment(mcfsParams);
		mcfs.run();
		
		GlobalStats gstats = mcfs.getGlobalStats();
		double wacc = gstats.getConfusionMatrix().calcMeasure(QualityMeasure.WACC);
		double acc = gstats.getConfusionMatrix().calcMeasure(QualityMeasure.ACC); 
		System.out.println("wacc: "+wacc);
		System.out.println("acc: "+acc);		
		assertEquals(new Double(MathUtils.truncate(0.734,3)), new Double(MathUtils.truncate(wacc,3)));
		assertEquals(new Double(MathUtils.truncate(0.822,3)), new Double(MathUtils.truncate(acc,3)));
		
		System.out.println(gstats.getCutoff().getCutoffTable());
		AttributesRI attrRI = gstats.getAttrImportances()[0];		
		Ranking topRanking = attrRI.getTopRankingSize(attrRI.mainMeasureIdx, 20);
		System.out.println(topRanking.toString());		
		Ranking refRanking = new Ranking();
		refRanking.load(resourcesPath + "AlizadehSimpleTopRanking.csv");
		System.out.println("** refRanking **");
		System.out.println(refRanking.toString());		
		assertEquals(refRanking.toString(), topRanking.toString());		

		String[] topAttr = topRanking.getAttributesNames();
		String attrString = Arrays.toString(topAttr);
		String refString = "[GENE2368X, GENE2402X, GENE1553X, GENE1647X, GENE675X, GENE1602X, GENE524X, GENE650X, GENE669X, GENE642X, GENE834X, GENE539X, GENE655X, GENE531X, GENE641X, GENE733X, GENE236X, GENE2324X, GENE3621X, GENE536X]";
		System.out.println(attrString);
		System.out.println("** refString **");
		System.out.println(refString);
	}
	//***************************
	
}
