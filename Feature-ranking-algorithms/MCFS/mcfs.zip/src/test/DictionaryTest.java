package test;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

import dmLab.array.meta.Dictionary;

public class DictionaryTest {

	//***************************	
	@Test
	public void testDictionary() {
		System.out.println("#### testDictionary ####");
		System.out.println(Float.toString(Float.parseFloat("NaN")));

		Dictionary dict=new Dictionary();
		System.out.println(dict.toFloat("jeden"));
		System.out.println(dict.toFloat("dwa"));
		System.out.println(dict.toFloat("dwa"));
		System.out.println(dict.toFloat("trzy"));
		System.out.println(dict.toFloat("true"));
		System.out.println(dict.toFloat("dwa"));
		System.out.println(dict.toFloat("cztery"));
		System.out.println(dict.toFloat("pięć"));
		System.out.println(dict.toFloat("sześć"));
		System.out.println(dict.toFloat("sześć"));

		System.out.println("*** just created");
		System.out.println(dict.toString());

		assertEquals("true", dict.toString(dict.toFloat("true")));
		assertEquals("jeden", dict.toString(dict.toFloat("jeden")));
		assertEquals("dwa", dict.toString(dict.toFloat("dwa")));
		assertEquals("cztery", dict.toString(dict.toFloat("cztery")));
		//assertEquals(null, dict.toString(dict.toFloat("dwieście")));
		assertEquals("dwieście", dict.toString(dict.toFloat("dwieście")));

		assertEquals(new Float(Float.NaN), new Float(dict.toFloat("?")));
		assertEquals(new Float(Float.NaN), new Float(dict.toFloat("NAN")));
		assertEquals(new Float(Float.NaN), new Float(dict.toFloat("NA")));
		assertEquals(new Float(Float.POSITIVE_INFINITY), new Float(dict.toFloat("+inf")));
		assertEquals(new Float(Float.NEGATIVE_INFINITY), new Float(dict.toFloat("-inf")));
		assertEquals(new Float(1), new Float(dict.toFloat("true")));
		assertEquals(new Float(0), new Float(dict.toFloat("false")));
		
		String[] sf = dict.toString(dict.toFloat(new String[] {"dwa", "trzy", "cztery"}));
		System.out.println("toString(toFloat( "+Arrays.toString(sf));
		assertArrayEquals(new String[] {"dwa", "trzy", "cztery"}, sf);
				
		Dictionary dict2 = dict.clone();
		System.out.println("*** just copied");
		System.out.println(dict2.toString());
		assertEquals(dict.size(),dict2.size());
		assertEquals("cztery", dict2.toString(dict.toFloat("cztery")));
		dict2.clear();
		assertEquals(2,dict2.size());
	}
}
