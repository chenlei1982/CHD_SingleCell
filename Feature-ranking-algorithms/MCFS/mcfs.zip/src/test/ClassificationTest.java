package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;
import java.util.Random;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.FArray;
import dmLab.array.loader.File2Array;
import dmLab.classifier.Classifier;
import dmLab.classifier.PredictionResult;
import dmLab.experiment.classification.ClassificationBody;
import dmLab.experiment.classification.ClassificationParams;
import dmLab.mcfs.MCFSParams;
import dmLab.mcfs.attributesRI.AttributesRI;
import dmLab.mcfs.mcfsEngine.MCFSFinalCV;
import dmLab.utils.cmatrix.QualityMeasure;
import dmLab.utils.dataframe.DataFrame;

public class ClassificationTest {
	
	public static String resourcesPath;
	public static FArray weatherArray = new FArray();
	public static FArray irisArray = new FArray();
	public static FArray soybeanArray = new FArray();
	public static FArray zooArray = new FArray();

	//***************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");		
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		File2Array file2Container=new File2Array();		
		assertTrue("weather",file2Container.load(weatherArray, resourcesPath+"//weather.adx"));
		assertTrue("iris",file2Container.load(irisArray, resourcesPath+"//iris.adx"));
		assertTrue("soybean",file2Container.load(soybeanArray, resourcesPath+"//soybean.adx"));
		assertTrue("zoo",file2Container.load(zooArray, resourcesPath+"//zoo.adx"));
		System.out.println("#### END before ####");
		System.out.println();
	}
	//***************************
	@Test
	public void testParams() {
		MCFSParams p = new MCFSParams();
		System.out.println(p);
		p.verbose = true;
		p.label = "TEST_LABEL"; 
				
		MCFSParams p2 = p.clone();
		p.setDefault();

		System.out.println(p2);
		assertEquals(new Boolean(true), p2.verbose);
		assertEquals("TEST_LABEL", p2.label);
		
		assertEquals(new Boolean(false), p.verbose);
		assertEquals("MCFS", p.label);
	}
	//***************************	
	@Test
	public void testMCFSFinalCV() {
    	FArray array = zooArray;
    	array.setDecAttrIdx(array.getColIndex("animaltype"));
    	array.setAllDecValues();
    	array.findDomains();

    	System.out.println("Array size: "+ array.colsNumber()+" "+array.rowsNumber());
    	System.out.println(Arrays.toString(array.getDecValuesStr()));
    	AttributesRI imp = new AttributesRI();
    	imp.load(resourcesPath+"//zoo__importances.csv");
    	
    	Random random = new Random(0);
    	MCFSFinalCV simpleCV = new MCFSFinalCV(new int[]{Classifier.J48,Classifier.NB,Classifier.SVM,Classifier.KNN,Classifier.LOGISTIC},random);
    	DataFrame df = simpleCV.run(array, imp, new int[]{5,10,15,20,25}, 10, 1000, 3);
    	System.out.println(df.toString());
    	
		assertEquals(15,df.rows());
		assertEquals("15",df.get(14, 0));
		assertEquals("logistic",df.get(14, 1));
		assertEquals(new Float(0.9306931f), (Float)df.get(14, 2));
		assertEquals(new Float(0.85365856f), (Float)df.get(7, 3));		
		assertEquals(new Float(0.83928573f), (Float)df.get(14, 3));
		assertEquals(new Float(0.6250871f), (Float)df.get(1, 3));
		
    	df = simpleCV.run(array, imp, new int[]{5,10,15,20,25}, 10, 90, 3);
    	System.out.println(df.toString());
    	
		assertEquals(15,df.rows());
		assertEquals("15",df.get(14, 0));
		assertEquals("knn",df.get(13, 1));
		
		//System.out.println("MDR TEST 2 "+ (Float)df.get(13, 2) );
		//System.out.println("MDR TEST 3 "+ (Float)df.get(13, 3) );

		assertEquals(new Float(0.7253321f), (Float)df.get(5, 3));
		assertEquals(new Float(0.9629629f), (Float)df.get(13, 2));
	}
	//************************************
	@Test
	public void testM5(){
		ClassificationBody classification = new ClassificationBody(new Random(0));		
		classification.setParameters(new ClassificationParams());
		classification.classParams.verbose = true;
		classification.classParams.saveClassifier = false;
		classification.classParams.savePredictionResult = false;
		classification.classParams.folds = 3;
		classification.classParams.repetitions = 3;
		classification.classParams.model = Classifier.M5;
		classification.initClassifier();
		FArray cvarray = weatherArray.clone();
		cvarray.setDecAttrIdx(cvarray.getColIndex("temperature"));

		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		PredictionResult predRes = classification.runCV(cvarray);		
		System.out.println("#######################################");
		assertEquals(new Float(-0.12616287f), (Float)(float)predRes.getPredQuality());		
		System.out.println(classification.toStringResults());

		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		predRes = classification.runTrainTest(cvarray,null);
		System.out.println("#######################################");
		System.out.println(classification.toStringResults());
		assertEquals(new Float(5.0240145f), (Float)(float)predRes.getPredQuality(QualityMeasure.RMSE));
	}
	//************************************

}
