package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.FArray;
import dmLab.array.loader.File2Array;
import dmLab.mcfs.MCFSParams;
import dmLab.mcfs.attributesRI.AttributesRI;
import dmLab.mcfs.attributesRI.measuresRI.ClassifiersMeasure;
import dmLab.mcfs.attributesRI.measuresRI.NodesMeasure;
import dmLab.mcfs.attributesRI.measuresRI.ImportanceMeasure;
import dmLab.mcfs.attributesRI.measuresRI.J48RIMeasure;
import dmLab.mcfs.attributesRI.measuresRI.ProjectionMeasure;
import dmLab.mcfs.attributesRI.measuresRI.RINormMeasure;

public class AttributesRITest {
	
	public static String resourcesPath;
	public static FArray weatherArray = new FArray();

	//***************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");		
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		File2Array file2Container=new File2Array();		
		assertTrue("weather",file2Container.load(weatherArray, resourcesPath+"//weather.adx"));
		System.out.println("#### END before ####");	
	}
	//***************************	

	@Test
	public void testRI() {
		System.out.println("testRI");
        AttributesRI importances = new AttributesRI(weatherArray);        
        importances.addMeasure(new ProjectionMeasure(null));            
        importances.addMeasure(new ClassifiersMeasure(null));
        importances.addMeasure(new NodesMeasure(null));
        importances.addMeasure(new J48RIMeasure(new MCFSParams()));
        importances.addMeasure(new RINormMeasure(null));        
        importances.mainMeasureIdx = importances.getMeasureIndex(ImportanceMeasure.MEASURE_RI);
        importances.label = "all";  
        importances.initImportances();

        System.out.println(weatherArray.toString());
        System.out.println(importances.toString());
        System.out.println(Arrays.toString(importances.getMeasuresNames()));
        assertEquals(4, importances.getAttributesNumber());
        assertEquals(5, importances.getMeasuresNames().length);
        assertEquals(3, importances.getMeasureIndex(ImportanceMeasure.MEASURE_RI_ROUGH));
        
	}

}
