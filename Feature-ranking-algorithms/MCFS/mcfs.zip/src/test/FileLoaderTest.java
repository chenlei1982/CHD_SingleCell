package test;

import static org.junit.Assert.assertEquals;

import java.io.File;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.Array;
import dmLab.array.FArray;
import dmLab.array.loader.File2Array;
import dmLab.array.loader.fileLoader.FileType;
import dmLab.array.saver.Array2File;
import dmLab.utils.StringUtils;

public class FileLoaderTest {
	
	public static String resourcesPath;

	//***************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");		
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		System.out.println("#### END before ####");	
	}
	//***************************
	@Test
	public void File2ContainerTest() {
		System.out.println("#### File2ContainerTest ####");
		
		File2Array f = new File2Array();
		Array container = new FArray();
		String inputFileName = resourcesPath + "weather.adx";
		f.load(container, inputFileName);
		Array2File c2file=new Array2File();

		System.out.println("************** CSV ****************");
		c2file.fileType.setType(FileType.CSV);
		System.out.println(c2file.toString(container));
		
		System.out.println("************** ADX ****************");
		c2file.fileType.setType(FileType.ADX);
		System.out.println(c2file.toString(container));
		
		System.out.println("************** ARFF ****************");
		c2file.fileType.setType(FileType.ARFF);
		System.out.println(c2file.toString(container));         
	}
	//**********************************************
	@Test
	public void ReadADH() {
		System.out.println("#### ReadADH ####");
		
		System.out.println(StringUtils.trimQuotation("'cbxbxmbmkjh'"));
		System.out.println(StringUtils.trimQuotation("\"cbxbxmbmkjh\""));
		System.out.println(StringUtils.trimQuotation("\"cbxbx'mbmkjh\""));

		File2Array f = new File2Array();
		Array container = new FArray();
		String inputFileName = resourcesPath + "/quotation_data.adh";
		f.load(container, inputFileName);
		
	    assertEquals(70, container.rowsNumber());
	    assertEquals(17, container.colsNumber());
	    assertEquals("X'2", container.attributes[1].name);

	}
}
