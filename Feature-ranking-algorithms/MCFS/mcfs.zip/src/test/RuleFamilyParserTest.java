package test;

import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.FArray;
import dmLab.array.loader.File2Array;
import dmLab.array.meta.Attribute;
import dmLab.classifier.adx.ADXParams;
import dmLab.classifier.adx.ruleFamily.RuleFamily;
import dmLab.classifier.adx.ruleParser.RuleFamilyParser;
import dmLab.utils.helpers.ParsingException;

public class RuleFamilyParserTest {
	
	public static String resourcesPath;
	public static FArray weatherArray = new FArray();
	
	//***************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");		
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		File2Array file2Container=new File2Array();		
		assertTrue("ali",file2Container.load(weatherArray, resourcesPath+"//weather.adx"));
		System.out.println("#### END before ####");	
	}	
	//***************************	
	@Test
	public void test1()
	{
		FArray eventsArray=new FArray(4,1);
		int eventPointer=0;

		eventsArray.attributes[eventPointer].name="A1";
		eventsArray.attributes[eventPointer].type=Attribute.NUMERIC;
		eventPointer++;
		
		eventsArray.attributes[eventPointer].name="A2";
		eventsArray.attributes[eventPointer].type=Attribute.NUMERIC;
		eventPointer++;
		
		eventsArray.attributes[eventPointer].name="A3";
		eventsArray.attributes[eventPointer].type=Attribute.NOMINAL;
		eventPointer++;
		
		eventsArray.attributes[eventPointer].name="D";
		eventsArray.attributes[eventPointer].type=Attribute.NOMINAL;
		eventPointer++;
		
		String dec[]=new String [1];
		dec[0]="good";
		eventsArray.setDecAttrIdx(eventsArray.getColIndex("D"));
		eventsArray.setDecValues(dec);
		
		RuleFamily myRuleFamily =new RuleFamily(eventsArray.getDecValues().length,eventsArray.colsNumber(),new ADXParams());
		myRuleFamily.setTrainArray(eventsArray);
		RuleFamilyParser loadRules=new RuleFamilyParser(myRuleFamily,eventsArray);
		
		String rule[]=new String[10];			
		rule[0]="A1>=730.0 and A2=[7,4,8,13] and A3=[green,black] c:0.2 n:0.1 p:0.4 q:0.4";
		rule[1]="A1=[730.0;895.0) and A2=[2,5] and A3=blue p:0.4 n:0.5 ps:40 pn:20";
		rule[2]="A1=[730.0;895.0) and A2=[2,5] and A3=blue p:0.4 n:0.5 qf:0.1";
		rule[3]="A1=[730.0;895.0) and A2=[2,5] and A3=blue p:0.4 n:0.5";
		
		for(int i=0;i<rule.length;i++)
		{
			try{
				if(rule[i]!=null)
					loadRules.parseComplex(rule[i],0);//decision is 0
			}
			catch(ParsingException e){
				System.err.print(e.getMessage());
			}
		}			
		System.out.println(myRuleFamily.toString());
	}
	//***************************
	/*
	@Test
	public void test2()
	{		
        Array eventsArray = weatherArray;
				
		RuleFamily ruleFamily = new RuleFamily(eventsArray.getDecValues().length,eventsArray.getAttrNumber(), new ADXParams());
		ruleFamily.setTrainArray(eventsArray);
		RuleFamilyParser ruleParser = new RuleFamilyParser(ruleFamily,eventsArray);
		
		BufferedReader inputFile=null;
		String inputFileName=".//resources2//AlizadehDane_F.rls";
		try{
			inputFile = new BufferedReader(new FileReader(inputFileName));
		}
		catch (Exception e) {
			System.err.println("Error opening file. File: \""+inputFileName +"\" does not exist!");
			return;
		}
		String rule;
		try{
			while (null!=(rule=inputFile.readLine()))
				if(!rule.startsWith("#"))
					ruleParser.parseComplex(rule,0);//decision is 0
		}
		catch(ParsingException e){
			System.err.print(e.getMessage());
		}
		catch(IOException e){
			System.err.print(e.getMessage());
		}
		
		try{
			inputFile.close();
		} catch (IOException e){
			e.printStackTrace();
		}
		
		System.out.println("Rules loaded! ");
		ruleFamily.saveSelectors("test_sel");
		ruleFamily.saveRuleFamily("test_rul");
		return;
	}
	*/
//	*******************************************
	

}
