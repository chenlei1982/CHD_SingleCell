package test;

import static org.junit.Assert.*;

import org.junit.Test;

import dmLab.utils.dataframe.DataFrame;
import dmLab.utils.dataframe.ColumnMetaInfo;

public class DataFrameTest {

	//***************************	
	@Test
	public void testDataFrame() {
		System.out.println("#### testDataFrame ####");
    	DataFrame df = new DataFrame(5,3);
    	System.out.println("rows: " + df.rows());
    	System.out.println("cols: "+df.cols());
    	df.setColNames(new String[]{"a1","a2","a3"});
    	df.setColTypes(new short[]{ColumnMetaInfo.TYPE_NUMERIC,ColumnMetaInfo.TYPE_NUMERIC,ColumnMetaInfo.TYPE_NUMERIC});
    	int c=0;
        for(int i=0;i<df.rows();i++){
            for(int j=0;j<df.cols();j++){
            	df.set(i, j, c++);
            }
        }
        System.out.println("#### df2 clone ####");
        DataFrame df2 = df.clone();
    	System.out.println(df2.toString());
    	assertEquals(df.rows(),df2.rows());
    	assertEquals(df.cols(),df2.cols());
    	assertArrayEquals(df.getColNames(),df2.getColNames());    	
    	assertArrayEquals(df.getColTypes(),df2.getColTypes());
    	
        System.out.println("#### df2 cbind ####");
        df2.setColNames(new String[]{"a11","a12","a13"});
    	System.out.println(df.toString());
    	System.out.println(df2.toString());
        
    	df2.cbind(df);
    	System.out.println(df2.toString());
    	assertEquals(df.rows(),df2.rows());
    	assertEquals(df.cols()*2,df2.cols());
    	
        System.out.println("#### df3 rbind ####");
        DataFrame df3 = df2.clone();        
    	df3.rbind(df2);
    	System.out.println(df3.toString());
    	assertEquals(df2.rows()*2,df3.rows());
    	assertEquals(df2.cols(),df3.cols());
    	assertEquals(4, df3.getColIdx("a2"));
    	
        System.out.println("#### df4 ####");
		DataFrame df4 = new DataFrame(1, df3);
		df4.set(0, 0, 100);
		df4.set(0, 1, 101);
		df4.set(0, 2, 102);
		df4.set(0, 3, 103);
		df4.set(0, 4, 104);
    	System.out.println(df4.toString());
    	
    	assertEquals(1, df4.rows());
    	assertEquals(df3.cols(), df4.cols());
    	assertEquals(103, df4.get(0, 3));
    	assertArrayEquals(df3.getColNames(), df4.getColNames());    	
    	assertArrayEquals(df3.getColTypes(), df4.getColTypes());    	

        System.out.println("#### df3 rbind ####");
    	df3.rbind(df4);
    	System.out.println(df3.toString());
    	assertEquals(11, df3.rows());
    	assertEquals(6, df3.cols());
    	assertEquals(103, df3.get(10, 3));    	
	}
	//***************************
	@Test
	public void testMathOperation() {
		System.out.println("#### testMathOperation ####");
    	DataFrame df = new DataFrame(5,3);
    	System.out.println("rows: " + df.rows());
    	System.out.println("cols: "+df.cols());
    	df.setColNames(new String[]{"a1","a2","a3"});
    	df.setColTypes(new short[]{ColumnMetaInfo.TYPE_NUMERIC, ColumnMetaInfo.TYPE_NUMERIC, ColumnMetaInfo.TYPE_NUMERIC});
    	int c=0;
        for(int i=0;i<df.rows();i++){
            for(int j=0;j<df.cols();j++){
            	df.set(i, j, new Float(c++));
            }
        }
    	System.out.println(df.toString());
    	DataFrame df2 = df.clone();
    	df2.mathOperation(df, "-");
    	System.out.println(df.toString());

    	assertEquals(0.0f, df2.get(0, 0));
    	assertEquals(0.0f, df2.get(1, 1));
    	assertEquals(0.0f, df2.get(2, 2));    	
	}
	//***************************
	@Test
	public void testGetRows() {
		System.out.println("#### testGetRows ####");
    	DataFrame df = new DataFrame(5,3);
    	System.out.println("rows: " + df.rows());
    	System.out.println("cols: "+df.cols());
    	df.setColNames(new String[]{"a1","a2","a3"});
    	df.setColTypes(new short[]{ColumnMetaInfo.TYPE_NUMERIC,ColumnMetaInfo.TYPE_NUMERIC,ColumnMetaInfo.TYPE_NUMERIC});
    	int c=0;
        for(int i=0;i<df.rows();i++){
            for(int j=0;j<df.cols();j++){
            	df.set(i, j, c++);
            }
        }
        System.out.println(df.toString());

        int[] rows = {1,3,4};
        DataFrame df2 = df.includeRows(rows);
        System.out.println(df2.toString());
        assertEquals(3, df2.rows());

        DataFrame df3 = df2.excludeRows(new int[] {1});
        System.out.println(df3.toString());
        assertEquals(3, df3.get(0, 0));
        int a2Idx = df3.getColIdx("a2");
        assertEquals(1, a2Idx);
                
        assertEquals(-1, df3.getColIdx("a145"));
	}
	//***************************	
}
