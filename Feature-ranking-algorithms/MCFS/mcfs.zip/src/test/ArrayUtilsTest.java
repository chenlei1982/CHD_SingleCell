/*******************************************************************************
 * #-------------------------------------------------------------------------------
 * # dmLab 2003-2019
 * # All rights reserved. This program and the accompanying materials
 * # are made available under the terms of the GNU Public License v3.0
 * # which accompanies this distribution, and is available at
 * # http://www.gnu.org/licenses/gpl.html
 * # 
 * #-------------------------------------------------------------------------------
 * # @description: data mining (dmLab) library that implements MCFS-ID algorithm
 * # @author: Michal Draminski [mdramins@ipipan.waw.pl]
 * # @company: Polish Academy of Sciences - Institute of Computer Science
 * # @homepage: http://www.ipipan.eu/
 * #-------------------------------------------------------------------------------
 * # Algorithm 'SLIQ' developed by Mariusz Gromada
 * # R Package developed by Michal Draminski & Julian Zubek
 * #-------------------------------------------------------------------------------
 *******************************************************************************/
package test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;
import java.util.Random;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.FArray;
import dmLab.array.functions.SelectFunctions;
import dmLab.array.loader.File2Array;
import dmLab.array.meta.AttributesMetaInfo;
import dmLab.utils.ArrayUtils;
import dmLab.utils.MathUtils;
import dmLab.utils.helpers.MinMax;
import dmLab.utils.roulette.RouletteInput;
import dmLab.utils.roulette.RouletteSelection;

public class ArrayUtilsTest {
	
	public static String resourcesPath;
	public static FArray weatherArray = new FArray();
	public static FArray irisArray = new FArray();
	public static FArray soybeanArray = new FArray();
	
	//********************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");		
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		File2Array file2Container=new File2Array();		
		assertTrue("weather",file2Container.load(weatherArray, resourcesPath+"//weather.adx"));
		assertTrue("iris",file2Container.load(irisArray, resourcesPath+"//iris.adx"));
		assertTrue("soybean",file2Container.load(soybeanArray, resourcesPath+"//soybean.adx"));
		System.out.println("#### END before ####");	
	}
	//********************************
	@Test
	public void randomFill_test(){
		ArrayUtils arrayutils = new ArrayUtils();		
		int array[] = new int[15];
		int repeat = 50;		
		double start = System.currentTimeMillis();
		for(int i = 0; i<repeat; i++){
			//Arrays.fill(array, 0);
			arrayutils.randomSelect(array, 4, 1, 0);
			System.out.println(Arrays.toString(array));
			//System.out.println(Arrays.toString(posIdx.toArray()));
			assertEquals(4,MathUtils.sum(array));			
		}		
		System.out.println("time: " + (System.currentTimeMillis()-start));
		
		System.out.println("#################");
		start = System.currentTimeMillis();
		for(int i = 0; i<repeat; i++){
			//Arrays.fill(array, 1);
			 arrayutils.randomSelect(array, 12, 1, 0);
			System.out.println(Arrays.toString(array));
			//System.out.println(Arrays.toString(posIdx.toArray()));			
			assertEquals(12,MathUtils.sum(array));			
		}				
		System.out.println("time: " + (System.currentTimeMillis()-start));
	}	
	//********************************	
	@Test
	public void testZooWeights(){
		System.out.println("#### testZooWeights ####");
		FArray array=new FArray();
		File2Array file2Container=new File2Array();
		assertTrue("",file2Container.load(array,resourcesPath+"//zoo_weights.adx"));
		System.out.println(array.toString());
		
		assertEquals(15,array.colsNumber());
		assertEquals(101,array.rowsNumber());
		assertEquals(14,array.getDecAttrIdx());
		array.buildAttributesMetaInfo(true);
		assertEquals(3,array.buildAttributesMetaInfo(false).getAttribute("animal").weight);
		assertEquals(1,array.buildAttributesMetaInfo(false).getAttribute("milk").weight);
		assertEquals(1,array.buildAttributesMetaInfo(false).getAttribute("tail").weight);
		assertEquals(3,array.buildAttributesMetaInfo(false).getAttribute("animaltype").weight);
		Random rnd = new Random(0);
		AttributesMetaInfo attrMetaInfo = array.buildAttributesMetaInfo(false);
		System.out.println(attrMetaInfo.toString());

		assertEquals(4,attrMetaInfo.getWeightsSize());
		assertArrayEquals(new Integer[]{5,6,7}, attrMetaInfo.getIndexArray((short)2));
		
		RouletteInput rouletteInput = attrMetaInfo.getRouletteInput();
		int dstColumns = 10;
		RouletteSelection rouletteSelection = new RouletteSelection(rnd);
		int[] selected = rouletteSelection.run(rouletteInput, dstColumns);
		System.out.println(rouletteInput.toString());				
		System.out.println("selected: " + Arrays.toString(selected));
		
		int[] mask = rouletteSelection.select(attrMetaInfo, rouletteInput);
		//add decision attribute
		mask[array.getDecAttrIdx()] = 1;

		// Use 
		SelectFunctions selectFunctions = new SelectFunctions(rnd);
		mask = selectFunctions.getColumnsMask(array, dstColumns);
		System.out.println("SelectFunctions: " + Arrays.toString(mask));
		assertArrayEquals(new int[]{1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1}, mask);
		
	}
	//***************************
	@Test
	public void testFixAttributes(){
		System.out.println("#### testFixAttributes ####");
		FArray array=new FArray();
		File2Array file2Container=new File2Array();
		assertTrue("",file2Container.load(array,resourcesPath+"//zoo_weights.adx"));
		array.attributes[1].name = "mcfs_contrast_attr_1";
		array.attributes[2].name = "tail";
		array.attributes[3].name = "mcfs_contrast_attr_1";
		array.attributes[4].name = "tail";
		array.attributes[5].name = "mcfs_contrast_attr_1";
		array.fixAttributesNames(true);
		System.out.println(array.toString());
		assertEquals("x_mcfs_contrast_attr_1", array.attributes[1].name);
		assertEquals("tail", array.attributes[2].name);
		assertEquals("x_mcfs_contrast_attr_1.1", array.attributes[3].name);
		assertEquals("tail.1", array.attributes[4].name);
		assertEquals("x_mcfs_contrast_attr_1.2", array.attributes[5].name);
		assertEquals("tail.2", array.attributes[11].name);
	}
	//***************************
	@Test
	public void testScaleArray(){
		System.out.println("#### testScaleArray ####");
		float[] array = new float[]{9f,8f,7f,6f,5f,4f,3f,-2f,-1f,0f};
		
		float[] scaled = ArrayUtils.scaleArray(array, 0, 4 * 0.999f, false);
		System.out.println(Arrays.toString(scaled));
		assertEquals(new Double(MathUtils.truncate(2.22,5)), new Double(MathUtils.truncate(scaled[4],3)));
		assertEquals(new Double(-1), new Double(scaled[8]));

		scaled = ArrayUtils.scaleArray(array, 0, 4 * 0.999f, true);
		System.out.println(Arrays.toString(scaled));
		assertEquals(new Double(MathUtils.truncate(2.8123949,5)), new Double(MathUtils.truncate(scaled[4],5)));
		assertEquals(new Double(MathUtils.truncate(0.6664443,5)), new Double(MathUtils.truncate(scaled[8],5)));
		assertEquals(new Double(MathUtils.truncate(1.3328886,5)), new Double(MathUtils.truncate(scaled[9],5)));				
	}
	//***************************
	@Test
	public void testMinMax(){
		System.out.println("#### testScaleArray ####");
		float[] array = new float[]{9f,8f,7f,6f,5f,4f,3f,-2f,-1f,0f};
	
		MinMax mm = ArrayUtils.getMinMax(array, true);
		System.out.println(mm);
		assertEquals(new Float(-2f),new Float(mm.minValue));
		assertEquals(new Float(9f),new Float(mm.maxValue));
		
		mm = ArrayUtils.getMinMax(array, false);
		System.out.println(mm);
		assertEquals(new Float(0f),new Float(mm.minValue));
		assertEquals(new Float(9f),new Float(mm.maxValue));

		array = new float[]{Float.NaN,Float.NaN,Float.NaN,Float.NaN};
		mm = ArrayUtils.getMinMax(array, true);
		System.out.println(mm);		
	}
}
