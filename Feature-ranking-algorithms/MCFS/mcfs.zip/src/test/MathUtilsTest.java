package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import dmLab.mcfs.mcfsEngine.MCFSAutoParams;
import dmLab.utils.statFunctions.StatFunctions;
import jdistlib.disttest.NormalityTest;

public class MathUtilsTest {

	@Test
	public void tTestOneSample_test() {
		double[] x = new double[]{65, 78, 88, 55, 48, 95, 66, 57, 79, 81};
		double y = 70;
		double p = StatFunctions.tTestOneSample(x,y);
		assertEquals(new Double(0.8102459931509158), new Double(p));		
	}
	//********************************
	@Test
	public void shapiro_test() {
		double[] x = new double[]{65, 78, 88, 55, 48, 95, 66, 57, 79, 81};
    	double w = NormalityTest.shapiro_wilk_statistic(x);
    	double p = NormalityTest.shapiro_wilk_pvalue(w, x.length);
		System.out.println("broken value w= "+w);
		System.out.println("broken value p= "+p);
		//W = 0.96239, p-value = 0.8128

		//*** this test is broken in 		
		//assertEquals(new Double(0.96239), new Double(w));
		//assertEquals(new Double(0.8128), new Double(p));		
	}
	//********************************
	@Test
	public void anderson_test() {
		double[] x = new double[]{65, 78, 88, 55, 48, 95, 66, 57, 79, 81};
    	double a = NormalityTest.anderson_darling_statistic(x);
    	double p = NormalityTest.anderson_darling_pvalue(a, x.length);
		//A = 0.21918, p-value = 0.775				
		assertEquals(new Double(0.2191777073573995), new Double(a));
		assertEquals(new Double(0.7750162701100167), new Double(p));
	}
	//********************************
	@Test
	public void bmodel_test() {
		System.out.println("### " + MCFSAutoParams.balanceModel(0.175f));
		System.out.println("### " + MCFSAutoParams.balanceModel(0.5f));
		System.out.println("### " + MCFSAutoParams.balanceModel(0.0345f));
		System.out.println("### " + MCFSAutoParams.balanceModel(0.0001f));
		System.out.println("### " + MCFSAutoParams.balanceModel(0.00001f));		
	}	
	//********************************
}


