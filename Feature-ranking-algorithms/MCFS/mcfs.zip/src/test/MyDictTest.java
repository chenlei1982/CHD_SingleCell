package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import dmLab.utils.MyDict;

public class MyDictTest {
	
	//***************************
	@Test
	public void testMyDict() {
	     MyDict dict=new MyDict();
	     System.out.println("PUT");
	     System.out.println(dict.put("marysia"));
	     System.out.println(dict.put("zosia"));
	     System.out.println(dict.put("zosia"));
	     System.out.println(dict.put("zofia"));
	     System.out.println(dict.put("marysia"));
	     System.out.println(dict.toString());
	     System.out.println("GET");	     
	     System.out.println(dict.get("marysia"));
	     System.out.println(dict.get(13));	     
	     dict.toString();
	     
	     assertEquals(new Integer(2), dict.get("zofia"));
	     assertEquals("marysia", dict.get(0));
	     assertEquals(null, dict.get("xxx"));
	     assertEquals(null, dict.get(13));
	     
	     MyDict dict2 = dict.clone();
	     assertEquals(dict.get("zosia"), dict2.get("zosia"));	     
	}
	//***************************
}
