package test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;

import org.junit.BeforeClass;
import org.junit.Test;

import dmLab.array.Array;
import dmLab.array.FArray;
import dmLab.array.domain.ADXDomain;
import dmLab.array.functions.ExtFunctions;
import dmLab.array.functions.SelectFunctions;
import dmLab.array.loader.File2Array;
import dmLab.array.loader.fileLoader.FileLoaderADX;
import dmLab.array.saver.Array2Instances;
import dmLab.mcfs.mcfsEngine.MCFSAutoParams;
import dmLab.utils.ArrayUtils;
import dmLab.utils.MathUtils;
import dmLab.utils.condition.Condition;
import dmLab.utils.condition.Operator;
import weka.core.Instances;
public class ArrayTest {

	public static String resourcesPath;
	public static FArray weatherArray = new FArray();
	public static FArray irisArray = new FArray();
	public static FArray soybeanArray = new FArray();
	
	//***************************
	@BeforeClass
	public static void prepare(){
		System.out.println("#### START before ####");		
		File currentDirectory = new File(new File(".").getAbsolutePath());
		resourcesPath = currentDirectory.getAbsolutePath()+"/src/test/resources/";
		File2Array file2Container=new File2Array();		
		assertTrue("weather",file2Container.load(weatherArray, resourcesPath+"//weather.adx"));
		assertTrue("iris",file2Container.load(irisArray, resourcesPath+"//iris.adx"));
		assertTrue("soybean",file2Container.load(soybeanArray, resourcesPath+"//soybean.adx"));
		System.out.println("#### END before ####");	
	}
	//***************************	
	@Test
	public void testLoading() {
		System.out.println("#### testLoading ####");
		FArray array=new FArray();
		File2Array file2Container=new File2Array();
		assertTrue("",file2Container.load(array,resourcesPath+"//weather.adx"));
		System.out.println(array.toString());
		assertEquals(5,array.colsNumber());
		assertEquals(14,array.rowsNumber());
		assertEquals(4,array.getDecAttrIdx());
		assertEquals("sunny", array.readValueStr(0, 0));
		assertEquals("rainy", array.readValueStr(0, 5));
		assertEquals("false", array.readValueStr(3, 2));
		assertEquals("91.0", array.readValueStr(2, 13));
		assertEquals(new Float(91), new Float(array.readValue(2, 13)));
		assertEquals("yes", array.readValueStr(4, 12));
				
		assertTrue("",file2Container.load(array,resourcesPath+"//weather.csv"));
		System.out.println(array.toString());
		assertEquals(5,array.colsNumber());
		assertEquals(14,array.rowsNumber());
		assertEquals(-1,array.getDecAttrIdx());
		array.setDecAttrIdx(3);
		assertEquals(3,array.getDecAttrIdx());		
		assertEquals("sunny", array.readValueStr(0, 0));
		assertEquals("rainy", array.readValueStr(0, 5));
		assertEquals("FALSE", array.readValueStr(3, 2));
		assertEquals("91", array.readValueStr(2, 13));
		assertEquals("yes", array.readValueStr(4, 12));
	}
	//***************************	
	@Test
	public void testLoadingDoubleNames() {
		System.out.println("#### testLoadingDoubleNames ####");
		FArray array=new FArray();
		File2Array file2Container=new File2Array();
		assertTrue("",file2Container.load(array,resourcesPath+"//weatherTwinsNames.adx"));
		System.out.println(array.toString());
		
		assertEquals("outlook",array.attributes[0].name);
		assertEquals("outlook.1",array.attributes[1].name);
		assertEquals("outlook.2",array.attributes[3].name);
	}	
	//***************************	
	@Test
	public void testAddAttribute() {
		System.out.println("#### testAddContrast ####");	
		FArray referenceArray = weatherArray;
		FArray newAttrArray = referenceArray.clone(); 
		ExtFunctions.addAttribute(newAttrArray);
		System.out.println(referenceArray.toString());
		System.out.println(newAttrArray.toString());
		
		assertEquals(6, newAttrArray.colsNumber());
		assertEquals(14, newAttrArray.rowsNumber());
		assertEquals("attr_1", newAttrArray.attributes[5].name);
	}
	
	//***************************	
	@Test
	public void testAddContrast() {
		
		System.out.println("#### testAddContrast ####");	
		FArray referenceArray = weatherArray;
		FArray contrastArray = referenceArray.clone(); 
		ExtFunctions.addContrastAttributes(contrastArray);
		System.out.println(referenceArray.toString());
		System.out.println(contrastArray.toString());
		
		assertEquals(9,contrastArray.colsNumber());
		assertEquals(14,contrastArray.rowsNumber());
		assertEquals(4,contrastArray.getDecAttrIdx());
		assertEquals("mcfs_contrast_attr_humidity",contrastArray.attributes[7].name);
		assertEquals("mcfs_contrast_attr_outlook",contrastArray.getColNames(true)[5]);
	}
	//***************************	
	@Test
	public void testCondition() {
		System.out.println("#### testCondition ####");
		FArray inArray=weatherArray;
		
		String eventFilter = "play=yes";		
		Condition condition=new Condition(eventFilter);
		assertEquals("play",condition.attributeName);
		assertEquals("=",condition.operator.toString());
		assertEquals("yes",condition.value);
		
		FArray outArray=(FArray)SelectFunctions.selectRows(inArray, eventFilter);
		System.out.println(outArray.toString());
		assertEquals(5,outArray.colsNumber());
		assertEquals(9,outArray.rowsNumber());
		assertEquals(4,outArray.getDecAttrIdx());
		
		eventFilter = "outlook!=rainy";
		outArray=(FArray)SelectFunctions.selectRows(inArray, eventFilter);				
		System.out.println(outArray.toString());

		assertEquals(5,outArray.colsNumber());
		assertEquals(9,outArray.rowsNumber());
		assertEquals(4,outArray.getDecAttrIdx());
		
		eventFilter = "temperature>=80";
		outArray=(FArray)SelectFunctions.selectRows(inArray, eventFilter);				
		System.out.println(outArray.toString());

		assertEquals(5,outArray.colsNumber());
		assertEquals(4,outArray.rowsNumber());
		assertEquals(4,outArray.getDecAttrIdx());			
	}
	//***************************
	@Test
	public void testConditionNumeric(){
		System.out.println("#### testConditionNumeric ####");
		Operator o = new Operator("=");
		assertEquals(true, o.compare(Float.NaN, Float.NaN));
		assertEquals(false, o.compare(1, Float.NaN));
		assertEquals(false, o.compare(Float.NaN, 2));
		assertEquals(true, o.compare(1, 1));
		assertEquals(false, o.compare(1, 2));
		o = new Operator("!=");
		assertEquals(false, o.compare(Float.NaN, Float.NaN));
		assertEquals(true, o.compare(1, Float.NaN));
		assertEquals(true, o.compare(Float.NaN, 2));
		assertEquals(false, o.compare(1, 1));
		assertEquals(true, o.compare(1, 2));
		
		FArray array = weatherArray;
		System.out.println(array);
		array.writeValue(1,1,Float.NaN);
		System.out.println(array);
		
		boolean[] result = SelectFunctions.getRowMask(array, new Condition("temperature" + " != ?"));
		System.out.println(Arrays.toString(result));		
		boolean[] expected ={true, false, true, true, true, true, true, true, true, true, true, true, true, true};
        assertArrayEquals(expected, result);

		result = SelectFunctions.getRowMask(array, new Condition("temperature" + " = ?"));
		System.out.println(Arrays.toString(result));
		expected = new boolean[]{false, true, false, false, false, false, false, false, false, false, false, false, false, false};
        assertArrayEquals(expected, result);
	}	
	//***************************
	@Test
	public void testSplit() {
		System.out.println("#### testSplit ####");

		FArray inputArray = irisArray;
		float splitRatio = 0.6f;
		SelectFunctions selectFunctions = new SelectFunctions(new Random());
				
		System.out.println("inputArray");
		System.out.println(inputArray.toString());
		System.out.println("#### testSplitRandom ####");
		int splitMask[] = selectFunctions.getSplitMaskRandom(inputArray, splitRatio);
		Array[] trainTestArrays = SelectFunctions.split(inputArray, splitMask);
		FArray trainArray = (FArray)trainTestArrays[0];
		FArray testArray = (FArray)trainTestArrays[1];
		
		System.out.println("trainArray");
		System.out.println(trainArray.toString());
		assertEquals(5,trainArray.colsNumber());
		assertEquals(90,trainArray.rowsNumber());
		assertEquals(4,trainArray.getDecAttrIdx());

		System.out.println("testArray");
		System.out.println(testArray.toString());
		assertEquals(5,testArray.colsNumber());
		assertEquals(60,testArray.rowsNumber());
		assertEquals(4,testArray.getDecAttrIdx());
		
		float[] decColumn = testArray.getColumn(testArray.getDecAttrIdx());
		int[] d = ArrayUtils.distribution(decColumn, testArray.getDecValues());
		System.out.println(Arrays.toString(d));
		double mean = MathUtils.mean(ArrayUtils.int2double(d));
		System.out.println(Arrays.toString(d));
		System.out.println(mean);
		assertEquals(true, mean==20);
		
		System.out.println("#### testSplitUniform ####");
		splitRatio = 0.8f;
		splitMask = selectFunctions.getSplitMaskUniform(inputArray, splitRatio);
		trainTestArrays = SelectFunctions.split(inputArray, splitMask);
		trainArray = (FArray)trainTestArrays[0];
		testArray = (FArray)trainTestArrays[1];
		
		System.out.println("trainArray");
		System.out.println(trainArray.toString());
		assertEquals(5,trainArray.colsNumber());
		assertEquals(120,trainArray.rowsNumber());
		assertEquals(4,trainArray.getDecAttrIdx());

		System.out.println("testArray");
		System.out.println(testArray.toString());
		assertEquals(5,testArray.colsNumber());
		assertEquals(30,testArray.rowsNumber());
		assertEquals(4,testArray.getDecAttrIdx());

		decColumn = testArray.getColumn(testArray.getDecAttrIdx());
		d = ArrayUtils.distribution(decColumn, testArray.getDecValues());
		System.out.println(Arrays.toString(d));
		assertEquals(10,d[0]);
		assertEquals(10,d[1]);
		assertEquals(10,d[2]);
	}
	//***************************
	@Test
	public void testProjection() {
		System.out.println("#### testProjection ####");
		int projectionSize = 5;
		FArray inputArray = soybeanArray;
		SelectFunctions selectFunctions = new SelectFunctions(new Random());

		int[] colMask = selectFunctions.getColumnsMask(inputArray, projectionSize);
		FArray outArray = (FArray)SelectFunctions.selectColumns(inputArray, colMask);
		System.out.println(outArray.toString());
		
		assertEquals(projectionSize+1,outArray.colsNumber());
		assertEquals(683,outArray.rowsNumber());
		assertEquals(5,outArray.getDecAttrIdx());
	}
	//***************************
	@Test
	public void testBalance() {
		System.out.println("#### testBalance ####");
		int removeNumber = 40;
		int size = irisArray.rowsNumber();
		FArray inputArray = irisArray;
		int splitMask[] = new int[size];
		SelectFunctions selectFunctions = new SelectFunctions(new Random());

		for(int i=0;i<size-removeNumber;i++)
			splitMask[i]=1;
		//System.out.println(Arrays.toString(splitMask)); 
						
		Array[] trainTestArrays = SelectFunctions.split(inputArray, splitMask);
		FArray trainArray = (FArray)trainTestArrays[0];
		
		System.out.println(trainArray.toString());		
		assertEquals(5,trainArray.colsNumber());
		assertEquals(size-removeNumber,trainArray.rowsNumber());
		assertEquals(4,trainArray.getDecAttrIdx());
		
		int[] distribution = ArrayUtils.distribution(trainArray.getColumn(trainArray.getDecAttrIdx()), trainArray.getDecValues());
		System.out.println("Classes: "+Arrays.toString(trainArray.dictionary.toString(trainArray.getDecValues())));
		System.out.println("Classes before balance: "+Arrays.toString(distribution));
		String[] classes = trainArray.dictionary.toString(trainArray.getDecValues());
		HashMap<String, Integer> cntMap = new HashMap<String, Integer>();  

		for(int i=0;i<classes.length;i++){
			cntMap.put(classes[i], distribution[i]);
		}		
		assertEquals(50, cntMap.get("Iris-setosa").intValue());
		assertEquals(50, cntMap.get("Iris-versicolor").intValue());
		assertEquals(10, cntMap.get("Iris-virginica").intValue());
				
        int[] tmpBalancedClassSizes = MCFSAutoParams.getBalancedClassSizes(2, trainArray);

		FArray outArray = selectFunctions.balanceClasses(trainArray, tmpBalancedClassSizes);
		System.out.println(outArray.toString());

		assertEquals(5,outArray.colsNumber());
		assertEquals(56,outArray.rowsNumber());
		assertEquals(4,outArray.getDecAttrIdx());
		
		distribution = ArrayUtils.distribution(outArray.getColumn(outArray.getDecAttrIdx()), outArray.getDecValues());
		System.out.println("Classes after size: "+Arrays.toString(distribution));
						
		cntMap = new HashMap<String, Integer>();
		for(int i=0;i<classes.length;i++){
			cntMap.put(classes[i], distribution[i]);
		}		
		assertEquals(23, cntMap.get("Iris-setosa").intValue());
		assertEquals(23, cntMap.get("Iris-versicolor").intValue());
		assertEquals(10, cntMap.get("Iris-virginica").intValue());
	}
	
	//***************************
	@Test
	public void testLoadingMissing() {
		System.out.println("#### testLoadingMissing ####");
		FArray array=new FArray();
		File2Array file2Container=new File2Array();
		assertTrue("",file2Container.load(array,resourcesPath+"//weather_missing.adx"));
		System.out.println(array.toString());
		assertEquals(5,array.colsNumber());
		assertEquals(14,array.rowsNumber());
		assertEquals(4,array.getDecAttrIdx());
		
		assertEquals("sunny", array.readValueStr(0, 0));
		assertEquals("rainy", array.readValueStr(0, 5));
		assertEquals("false", array.readValueStr(3, 2));
		assertEquals("91.0", array.readValueStr(2, 13));
		assertEquals(new Float(91), new Float(array.readValue(2, 13)));
		assertEquals("yes", array.readValueStr(4, 12));
	}
	//***************************
	@Test
	public void testLoadingIgnored() {
		System.out.println("#### testLoadingIgnored ####");
		FArray array=new FArray();
		File2Array file2Container=new File2Array();
		assertTrue("",file2Container.load(array,resourcesPath+"//weather_ignored.adx"));
		System.out.println(array.toString());
		assertEquals(3,array.colsNumber());
		assertEquals(14,array.rowsNumber());
		assertEquals(2,array.getDecAttrIdx());
	}
	//***************************
	@Test
	public void testLoadingArff() {
		System.out.println("#### testLoadingArff ####");
		FArray array=new FArray();
		File2Array file2Array=new File2Array();
		assertTrue("",file2Array.load(array,resourcesPath+"//weather.arff"));
		assertEquals(5,array.colsNumber());
		assertEquals(14,array.rowsNumber());
		assertEquals(-1,array.getDecAttrIdx());
		System.out.println(array.toString());		

		array.setDecAttrIdx(4);
		array.setAllDecValues();
		
		assertEquals(4,array.getDecAttrIdx());
	}
	//***************************
	@Test
	public void testArray2Instances(){
		System.out.println("#### testArray2Instances ####");
        FArray array = weatherArray;
        System.out.println(array.toString());
        Instances instances = Array2Instances.convert(array);
        System.out.println(instances.toString());
		assertEquals(array.rowsNumber(), instances.numInstances());
		assertEquals(array.colsNumber(), instances.numAttributes());		
    }
	//***************************
	@Test
	public void testCopyDomain(){
		FArray array = weatherArray;
        array.findDomains();
		boolean[] rowMask ={false,false,true,false,false,false,false,false,false,false,false,false,true,true};
        FArray arraySample = array.clone(null, rowMask);
        System.out.println(arraySample.toString());
        String[] domain1 = array.getDomainStr(0);
        String[] domain2 = arraySample.getDomainStr(0);
        
        System.out.println(Arrays.toString(domain1));
        System.out.println(Arrays.toString(domain2));
        assertArrayEquals(domain1, domain2);
	}
	//***************************
	@Test
	public void testWeatherWeird(){
		System.out.println("#### testWeatherWeird ####");
		FArray array=new FArray();
		File2Array file2Container=new File2Array();
		assertTrue("",file2Container.load(array,resourcesPath+"//weather_weird.adx"));
		System.out.println(array.toString());
		assertEquals(5,array.colsNumber());
		assertEquals(13,array.rowsNumber());
		assertEquals(4,array.getDecAttrIdx());

		assertEquals("sun'ny",array.readValueStr(0, 0));
		assertEquals("su nny",array.readValueStr(0, 7));
		assertEquals("rai?ny",array.readValueStr(0, 4));
		assertEquals("over cast",array.readValueStr(0, 12));
		assertEquals("?",array.readValueStr(4, 6));
	}
	//***************************
	@Test
	public void testFindADXDomains(){
		System.out.println("#### testFindDomains ####");
		FArray array=weatherArray;
		array.findADXDomains();
		ADXDomain d = array.getADXDomain(0);
		assertEquals(new Float(d.calculate_Gini()),new Float(0.56114286));
		String domainStr="val: 2.0	p:3 n:2	p:2 n:3\n"
				+ "val: 4.0	p:0 n:4	p:4 n:0\n"
				+ "val: 6.0	p:2 n:3	p:3 n:2\n"
				+ "totalPos: 5	totalNeg: 9\n"
				+ "totalPos: 9	totalNeg: 5\n"
				+ "#decision: 2";
		System.out.println("*** reference ***\n"+domainStr.trim());
		System.out.println("*** result ***\n"+d.toString().trim());
		assertEquals(domainStr.trim(), d.toString().trim());
	}
	//***************************
	@Test	
	public void testSplitConstructor(){
		System.out.println("#### testSplitConstructor ####");
		FArray array = weatherArray;
		
		array.findADXDomains();
		ADXDomain d1 = array.getADXDomain(0);
		System.out.println("*** result ***\n"+d1.toString().trim());		
		assertEquals(new Float(0.56114286), new Float(d1.calculate_Gini()));		

		boolean[] colMask ={true,false,true,false,true};
		boolean[] rowMask ={true,false,true,false,false,false,false,false,false,false,false,false,true,true};		
		FArray array2 = array.clone(colMask, rowMask); 
		
		System.out.println(array.toString());
		System.out.println(array2.toString());
		
		String array2Str="attributes\n"
				+ "{\n"
				+ " outlook	nominal	[1]\n"
				+ " humidity	numeric	[1]\n"
				+ " play	nominal	[1]	decision(no,yes)\n"
				+ "}\n"
				+ "events\n"
				+ "{\n"
				+ "sunny,85.0,no\n"
				+ "overcast,86.0,yes\n"
				+ "overcast,75.0,yes\n"
				+ "rainy,91.0,no\n"
				+ "}";
		System.out.println("*** reference ***\n"+array2Str.trim());
		System.out.println("*** result ***\n"+array2.toString().trim());
		assertEquals(array2Str.trim(), array2.toString().trim());
		
		
		array2.findADXDomains();
		ADXDomain d2 = array2.getADXDomain(0);
		System.out.println("*** result ***\n"+d2.toString().trim());		
		assertEquals(new Float(1.0), new Float(d2.calculate_Gini()));		
	}
	//***************************
	@Test	
	public void testCbind(){
		System.out.println("#### testCbind ####");
		boolean[] colMask ={true,false,true,false,true};
		FArray array1 = weatherArray.clone();
		FArray array2 = weatherArray.clone(colMask, null);
		array1.cbind(array2);
		array1.fixAttributesNames(false);
		
		FArray refArray = new FArray();
		File2Array file2Array=new File2Array();
		file2Array.load(refArray, resourcesPath + "//weatherExt.adx");

		System.out.print(array1);
		assertEquals(refArray.toString().trim(), array1.toString().trim());
	}
	//***************************	
	@Test	
	public void testShuffleColumns(){
		System.out.println("#### shuffleColumns ####");
		SelectFunctions selectFunctions = new SelectFunctions(new Random(1));
		FArray array1 = weatherArray.clone();
		FArray array2 = selectFunctions.shuffleColumns(array1);
		System.out.print(array1);
		System.out.print(array2);
		System.out.print(Arrays.toString(array2.getColNames(true)));
		String refCols = "[outlook, play, windy, temperature, humidity]";
		assertEquals(refCols,Arrays.toString(array2.getColNames(true)));
		assertArrayEquals(ArrayUtils.float2Float(array1.getColumn(4)), ArrayUtils.float2Float(array2.getColumn(1)));
		assertArrayEquals(ArrayUtils.float2Float(array1.getColumn(1)), ArrayUtils.float2Float(array2.getColumn(3)));
	}
	//***************************
	@Test	
	public void testDecisionNoAll(){
		File2Array file2Container=new File2Array();	
		FArray weatherNoAllArray = new FArray();
		file2Container.load(weatherNoAllArray, resourcesPath+"//weatherNoAll.adx");
		assertEquals(5,weatherNoAllArray.colsNumber());
		assertEquals(14,weatherNoAllArray.rowsNumber());
		assertEquals(4,weatherNoAllArray.getDecAttrIdx());		
		System.out.print(weatherNoAllArray);
		
		file2Container.load(weatherNoAllArray, resourcesPath+"//weatherNoAllNumeric.adx");
		assertEquals(5,weatherNoAllArray.colsNumber());
		assertEquals(14,weatherNoAllArray.rowsNumber());
		assertEquals(2,weatherNoAllArray.getDecAttrIdx());
		System.out.print(weatherNoAllArray);
		
	}
	//***************************
	@Test	
	public void testParseAttr(){
				
		assertEquals("C1 numeric 1 null", FileLoaderADX.parseAttribute("C1	numeric").toString());
		assertEquals("C2 nominal 1 null", FileLoaderADX.parseAttribute("		C2	nominal		").toString());
		assertEquals("C3 nominal 0 null", FileLoaderADX.parseAttribute("		C3	nominal	ignore	").toString());		
		assertEquals(null,FileLoaderADX.parseAttribute("		C4	aaa	ignore	"));
		assertEquals(null,FileLoaderADX.parseAttribute("		C4	nominal	abc	"));		 
		assertEquals("class1 nominal 2 [B, C, A]",FileLoaderADX.parseAttribute("class1	nominal	decision(B,C,A)").toString());
		assertEquals("class2 nominal 2 [B, C, A]",FileLoaderADX.parseAttribute("			class2	nominal	decision (B,C,A)").toString());
		assertEquals("class3 nominal 2 []",FileLoaderADX.parseAttribute("class3	nominal	decision(all)").toString());
		assertEquals("class4 nominal 2 []",FileLoaderADX.parseAttribute("class4	nominal	decision	(all)").toString());
		assertEquals(null,FileLoaderADX.parseAttribute("	  class5	nominal	decision()"));
		assertEquals(null,FileLoaderADX.parseAttribute("	  class6	nominal	decision(,,,)"));
		assertEquals("class7 nominal 2 []",FileLoaderADX.parseAttribute("	class7	nominal	decision").toString());		
	}
	//***************************	
}
