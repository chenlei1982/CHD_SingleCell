package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;

import java.util.Arrays;
import java.util.Random;

import org.junit.Test;

import dmLab.utils.GeneralUtils;
import dmLab.utils.MyEncrypt;
import dmLab.utils.ProgressCounter;
import dmLab.utils.StringUtils;
import dmLab.utils.roulette.RouletteInput;
import dmLab.utils.roulette.RouletteSelection;

public class UtilsTest {

	//************************
	@Test
	public void EncoderTest() {
		String s="haslo";
		System.out.println(s+" -> " + MyEncrypt.encodePassword(s));
		assertEquals("207023ccb44feb4d7dadca005ce29a64", MyEncrypt.encodePassword(s));
	}
	//************************
	@Test
	public void StringTokenizer() {
		char delims[] = new char[] {' ','	'};
		char quoteChar[] = new char[] {'\"','\''};
		String splitString = "\"one two\"   three	 fo#$%^&ur! ! five 	'six seven'			|ten eleven|";
		System.out.println("StringTokenizer Example: \n"+splitString);
		String[] tokens = StringUtils.tokenize(splitString, delims, quoteChar);
		System.out.println(Arrays.toString(tokens));
		assertEquals(8,tokens.length);
		assertEquals("one two",tokens[0]);
		assertEquals("fo#$%^&ur!",tokens[2]);
		assertEquals("eleven|",tokens[7]);
				
		quoteChar = new char[] {'\"','\'','|'};
		System.out.println("StringTokenizer Example: \n"+splitString);
		tokens = StringUtils.tokenize(splitString, delims, quoteChar);
		System.out.println(Arrays.toString(tokens));
		assertEquals(7,tokens.length);
		assertEquals("ten eleven",tokens[6]);
	}
	//************************
	@Test
	public void testTokenizeStringArray() {
		System.out.println("### testTokenizeStringArray ###");
		String inputFileName = "[\"diff_dec_stimulation.adx\",\"dec_stimulation.adx\"]";
		char delims[] = new char[] {',',';'};
		char quoteChar[] = new char[] {'\"','\''};		
		String[] tokens = StringUtils.tokenize(inputFileName, delims, quoteChar);
		for(int i=0;i<tokens.length;i++){
			System.out.println(tokens[i]);
		}
		String[] output = StringUtils.removeItems(tokens,new String[] {"[","]"});				
		System.out.println(Arrays.toString(output));
		
		assertEquals(4,tokens.length);
		assertEquals(2,output.length);
		assertEquals(output[1],"dec_stimulation.adx");
		
		System.out.println("########");
		String inputFileName2 = "[diff_dec_stimulation.adx,dec_stimulation.adx]";
		output = StringUtils.tokenizeArray(inputFileName2);
		System.out.println(Arrays.toString(output));
		
	}
	//************************
	@Test
	public void testTokenizeNumeric() {	
		String inputLine = "7A5	numeric"; 
		char separators[]=new char[]{' ','\t'};
		String[] tokens = StringUtils.tokenize(inputLine,separators,new char[] {'\"','\''});
		System.out.println(Arrays.toString(tokens));
		assertEquals(2,tokens.length);
		assertEquals("7A5",tokens[0]);
	}
	//************************
	@Test
	public void testProgressCounter() {		
		ProgressCounter pc = new ProgressCounter(30f, 230f, new float[]{0,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100});		
		//System.out.println(pc.getPercentValue(30)+"%");
		//System.out.println(pc.getPercentValue(30)+"%");
		assertEquals(new String("0"), pc.getPercentValue(30));
		assertEquals(null, pc.getPercentValue(30));
		System.out.println(pc.getPercentValue(50)+"%");
		System.out.println(pc.getPercentValue(50)+"%");
		System.out.println(pc.getPercentValue(51)+"%");
		System.out.println(pc.getPercentValue(52)+"%");
		System.out.println(pc.getPercentValue(53)+"%");
		System.out.println(pc.getPercentValue(55)+"%");
		System.out.println(pc.getPercentValue(60)+"%");		
		System.out.println(pc.getPercentValue(80)+"%");
		System.out.println(pc.getPercentValue(100)+"%");
		assertEquals(new String("50"), pc.getPercentValue(130));
		System.out.println(pc.getPercentValue(200)+"%");
		System.out.println(pc.getPercentValue(230)+"%");
		System.out.println(pc.getPercentValue(250)+"%");
		assertEquals(new String("100"), pc.getPercentValue(300));
	}	
	//************************
	@Test
	public void testTimeIntervalFormat() {
		System.out.println(GeneralUtils.timeIntervalFormat(0.1f));
		System.out.println(GeneralUtils.timeIntervalFormat(55f));
		System.out.println(GeneralUtils.timeIntervalFormat(134f));
		System.out.println(GeneralUtils.timeIntervalFormat(3500f));
		System.out.println(GeneralUtils.timeIntervalFormat(5000f));
		System.out.println(GeneralUtils.timeIntervalFormat(10000f));
	}
	//************************	
	@Test
	public void testAllIn() {	
		assertEquals(true,StringUtils.allin(new String[] {"a", "b", "c"}, new String[] {"a", "b", "c"}, false, true));
		assertEquals(true,StringUtils.allin(new String[] {"a", "b", "c"}, new String[] {"a", "b", "c", "d", "e"}, false, true));		
		assertEquals(true,StringUtils.allin(new String[] {"aa", "bb", "c"}, new String[] {"a", "b", "c", "bb", "aa"}, false, true));
		assertEquals(true,StringUtils.allin(new String[] {"aa", "bb", "c"}, new String[] {"a", "b", "c", "BB", "AA"}, true, true));
		assertEquals(true,StringUtils.allin(new String[] {"aa", "bb", "c"}, new String[] {"a", "b", "c", " BB ", "'AA'"}, true, true));

		assertEquals(false,StringUtils.allin(new String[] {"ab", "b", "c"}, new String[] {"a", "b", "c"}, false, true));
		assertEquals(false,StringUtils.allin(new String[] {"a", "b", "ca"}, new String[] {"a", "b", "c", "d", "e"}, false, true));		
		assertEquals(false,StringUtils.allin(new String[] {"aa", "bb", "cc"}, new String[] {"a", "b", "c", "bb", "aa"}, false, true));
		assertEquals(false,StringUtils.allin(new String[] {"aa", "bb", "c"}, new String[] {"a", "b", "c", "BB", "AA"}, false, true));
	}
	//************************
	@Test
	public void rouletteSelection_test(){
		long startTime;
		int[] selected;
		RouletteSelection rouletteSelection = new RouletteSelection(new Random(0));
		
		startTime = System.currentTimeMillis();
		selected = rouletteSelection.run(new RouletteInput(new short[] {0,1,2,5,10,100}, new int[] {1,300,300,20,10,5}), 100);			
		System.out.println("time:\t" + (System.currentTimeMillis() - startTime)/1000.0 + " s.");
		System.out.println("rouletteSelection:\n"+Arrays.toString(selected));
		assertArrayEquals(new int[] {0, 31, 44, 11, 9, 5}, selected);		
		
		startTime = System.currentTimeMillis();
		selected = rouletteSelection.run(new RouletteInput(new short[] {0,1,2,5,10,100}, new int[] {1,300,300,20,10,5}), 600);
		System.out.println("time:\t" + (System.currentTimeMillis() - startTime)/1000.0 + " s.");
		System.out.println("rouletteSelection:\n"+Arrays.toString(selected));
		assertArrayEquals(new int[] {0, 265, 300, 20, 10, 5}, selected);		

		startTime = System.currentTimeMillis();
		selected = rouletteSelection.run(new RouletteInput(new short[] {0,1,2,5,10,100,4}, new int[] {1,300,300,20,10,5,4}), 635);
		System.out.println("time:\t" + (System.currentTimeMillis() - startTime)/1000.0 + " s.");
		System.out.println("rouletteSelection:\n"+Arrays.toString(selected));
		assertArrayEquals(new int[] {0, 296, 300, 20, 10, 5, 4}, selected);		

		//null
		selected = rouletteSelection.run(new RouletteInput(new short[] {0,1,2,5,10,100}, new int[] {1,300,300,20,10,5}), 900);
		assertArrayEquals(null, selected);
		
	}
	//********************************
}
