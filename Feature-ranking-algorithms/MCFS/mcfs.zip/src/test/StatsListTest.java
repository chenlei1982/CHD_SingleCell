package test;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;

import dmLab.utils.GeneralUtils;
import dmLab.utils.statFunctions.StatFunctions;
import dmLab.utils.statList.StatsList;
import dmLab.utils.statList.StatsObject;

public class StatsListTest {

	//********************************
	@Test
	public void test() {
		StatsList s = new StatsList();
		s.addHeader("a,b,c,d",',');
		s.add(new StatsObject("0,1,2,3"));
		s.add(new StatsObject("1,1,2,3"));
		s.add(new StatsObject("2,1,2,3"));
		s.add(new StatsObject("3,1,2,3"));
		s.add(new StatsObject("4,1,2,3"));
		System.out.println(s.toString());		

		System.out.println(Arrays.toString(s.getCol("b")));
		System.out.println(Arrays.toString(s.getCol("f")));

		System.out.println(s.toStringSummary("a"));
		System.out.println(s.toStringSummary("f"));
	}
	//********************************
	@Test
	public void test_TTest() {

		double[] rnorm = new double[]{-0.414537199889859,-0.282025875261648,-0.226150575732024,0.328819927851957,-1.97773719535591,-0.110592009263439,-0.122189742688017,1.04007798487464,0.155206513715431,-0.0843735783514465,2.64539209745604,-0.363792555411382,-0.22087442115051,-0.714367364513306,-0.35357840201436,1.27160352644717,-0.627487788933113,2.39430741949789,-1.38885401965371,-1.16157785623268,-0.367762325303941,1.22919686481321,0.107033046603004,2.02865465853361,0.549783065097931,0.400324502850096,0.871550937509549,-1.07082898125181,-0.281756381691922,-1.36230108927328};
		double[] runif = new double[]{0.795595369767398,0.108063244493678,0.585204342845827,0.942154651740566,0.940392112359405,0.717013261280954,0.973356424598023,0.0954369565006346,0.790104218060151,0.725778691237792,0.868284542579204,0.727110652951524,0.599269720260054,0.000990098109468818,0.737845758441836,0.727144592208788,0.904881757451221,0.659799881279469,0.685408900259063,0.104847595095634,0.990287201246247,0.735420640790835,0.428024581866339,0.44712535222061,0.788217417430133,0.579983176430687,0.122100580018014,0.334795960923657,0.185680338647217,0.900798023445532};
		double mu = 0.5;	
		
		System.out.println("jdistlib: " + StatFunctions.tTestOneSample(rnorm, mu));
		assertEquals(new Double(0.03576491506001153), new Double(StatFunctions.tTestOneSample(rnorm, mu)));
		System.out.println("jdistlib: " + StatFunctions.tTestOneSample(runif, mu));
		assertEquals(new Double(0.061747372344183926), new Double(StatFunctions.tTestOneSample(runif, mu)));
		double[] values = rnorm;
		double alpha = 0.05;
		double pValue = StatFunctions.andersonDarlingNormTest(values);
		System.out.println("Anderson-Darling normality test p-value = " + GeneralUtils.formatFloat(pValue, 7));		
		double[] confidence = StatFunctions.getConfidenceInterval(alpha, values);
		System.out.println("Confidence Interval: "+ GeneralUtils.formatFloat(confidence[0],7)+" ; "+GeneralUtils.formatFloat(confidence[1],7));

		assertEquals(new Double(-0.3427991648364272), new Double(confidence[0]));
		assertEquals(new Double(0.4688767103883052), new Double(confidence[1]));
	}		
	//********************************


}
