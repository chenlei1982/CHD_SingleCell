package test;

import static org.junit.Assert.assertEquals;

import java.io.File;

import org.junit.Test;

import dmLab.mcfs.attributesID.AttributesID;

public class AttributesIDTest {

	@Test
	public void testAddConnection() {
		System.out.println("testAddConnection");
		String[] attr = {"a","b","c","d","e","f","g"};		
		AttributesID acl=new AttributesID(attr, true, false);
	    acl.addID("a", "a", 33);
	    acl.addID("a", "b", 1);
	    acl.addID("a", "c", 3);
	    acl.addID("a", "d", 1);
	    acl.addID("a", "b", 2);
	    acl.addID("c", "f", 8);
	    acl.addID("d", "a", 6);
	    acl.addID("d", "e", 7);
	    acl.addID("d", "f", 1);
	    acl.addID("d", "a", 6);
	    acl.addID("d", "a", 1);
	    
	    String s ="a,b(3.0),c(3.0),d(1.0)"+"\n"
	    		+"c,f(8.0)"+"\n"
	    		+"d,a(13.0),e(7.0),f(1.0)"+"\n";

	    System.out.println(acl.toString());	
	    System.out.println(acl.toConnString());
	    assertEquals(s, acl.toConnString());
	    assertEquals(new Double(13), new Double(acl.getMaxID()));
	    assertEquals(new Double(1), new Double(acl.getMinID()));
	}	
	//****************************************
	@Test
	public void testAddConnection2() {
		System.out.println("testAddConnection2");
		AttributesID acl=new AttributesID(true, true);
	    acl.addID("a", "a", 33);
	    acl.addID("a", "b", 1);
	    acl.addID("a", "c", 3);
	    acl.addID("a", "d", 1);
	    acl.addID("a", "b", 2);
	    System.out.println(acl.toString());	
	    System.out.println(acl.toConnString());
	    
	    String s="a,a(33.0),b(3.0),c(3.0),d(1.0)"+"\n";
	    assertEquals(s, acl.toConnString());
	}
	//****************************************
	@Test
	public void testAddConnections() {
	    System.out.println("testAddConnections");

		String[] attr = {"a","b","c","d","e","f","g"};
		AttributesID acl=new AttributesID(attr, true, true);
	    acl.addID("a", "a", 33);
	    acl.addID("a", "b", 1);
	    acl.addID("a", "c", 3);
	    acl.addID("a", "d", 1);
	    acl.addID("a", "b", 2);
	    System.out.println(acl.toString());	
	    System.out.println(acl.toConnString());

		AttributesID acl2 = new AttributesID(attr, true, true);
		acl2.addID("a", "b", 10);
		acl2.addID("a", "c", 30);
		acl2.addID("a", "d", 10);
		acl2.addID("a", "b", 20);
		acl2.addID("g", "f", 9);
	    System.out.println(acl2.toString());	
	    System.out.println(acl2.toConnString());		

	    acl.addAttributesID(acl2);
	    System.out.println(acl.toString());	
	    System.out.println(acl.toConnString());
		
	    String s="a,a(33.0),b(33.0),c(33.0),d(11.0)"+"\n"
	    		+"g,f(9.0)"+"\n";
	    assertEquals(s, acl.toConnString());
	}
	//****************************************
	@Test
	public void testCut() {
	    System.out.println("testFilter");
		
		AttributesID acl = new AttributesID(true, false);
	    acl.addID("a", "a", 33);
	    acl.addID("a", "b", 1);
	    acl.addID("a", "c", 3);
	    acl.addID("a", "d", 1);
	    acl.addID("a", "b", 2);
	    acl.addID("c", "f", 8);
	    acl.addID("d", "a", 6);
	    acl.addID("d", "e", 7);
	    acl.addID("d", "f", 1);
	    acl.addID("d", "a", 6);
	    acl.addID("d", "a", 1);
	    acl.addID("x", "y", 66);
	    acl.addID("x", "z", 77);
	    acl.addID("y", "x", 5);
	    acl.addID("z", "x", 77);
	    
	    System.out.println(acl.toString());	
	    System.out.println(acl.toConnString());
	    
	    System.out.println("filtering");
	    String[] selectedAttr = {"a","d","x","y"};
	    System.out.println(acl.filter(selectedAttr, 0));
	    System.out.println(acl.filter(null, 10));
	    System.out.println(acl.filter(selectedAttr, 10));
	}
	//****************************************
	@Test
	public void testLoad() {
		AttributesID acl = new AttributesID(true, false);		
		File currentDirectory = new File(new File(".").getAbsolutePath());
		acl.load(currentDirectory.getAbsolutePath()+"/src/test/resources/AlizadehData_connections1.csv");		
	    System.out.println(acl.toString());
	    assertEquals(new Float(6.2756767), new Float(acl.getMaxID()));
	    assertEquals(new Float(0.2247423), new Float(acl.getMinID()));
	    assertEquals(new Integer(13), new Integer(acl.getNodesNumber()));	    	    
	    assertEquals(new Integer(32), new Integer(acl.getEdgesNumber()));

		AttributesID acl2=new AttributesID(true, false);
		acl2.load(currentDirectory.getAbsolutePath()+"/src/test/resources/AlizadehData_connections2.csv");
	    System.out.println(acl2.toString());  	    
	    assertEquals(new Float(6.2756767), new Float(acl2.getMaxID()));
	    assertEquals(new Float(0.2247423), new Float(acl2.getMinID()));
	    assertEquals(new Integer(12), new Integer(acl2.getNodesNumber()));
	    assertEquals(new Integer(28), new Integer(acl2.getEdgesNumber()));
	}
	//****************************************	
}
